package controllers;

import dao.MonAnDAO;
import dao.ThongKeDAO;
import java.util.List;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import utils.MsgBox;
import utils.XInit;

public class QLDatMon {

    public static void setColsForBillTable(JTable tbl) {
        String[] cols = {"Tên Món", "Số Lượng", "ĐV", "Đơn Giá", "Thành Tiền"};
        int[] widthCols = {320, 50, 30, 100, 120};
        XInit.setCols(tbl, cols, widthCols);
    }

    public static void setColsForMenuTable(JTable tbl) {
        String[] cols = {"Tên Món", "ĐV", "Đơn Giá"};
        int[] widthCols = {320, 30, 100};
        XInit.setCols(tbl, cols, widthCols);
    }

    // fill dữ liệu lên bảng từ list Object[], list được lấy theo điều kiện id
    public static void fillToTblById(JTable tbl, List<Object[]> list) {
        DefaultTableModel tblModel = (DefaultTableModel) tbl.getModel();
        tblModel.setRowCount(0);
        if (list != null) {
            for (Object[] obj : list) {
                Object[] rows = new Object[obj.length];
                for (int i = 0; i < obj.length; i++) {
                    rows[i] = obj[i];
                }
                tblModel.addRow(rows);
            }
        } else {
            MsgBox.alert(tbl, "Không tìm thấy thông tin!");
        }
    }

    public static void fillToMenuTblById(String maLoaiMon, JTable tbl) {
        List<Object[]> list = QLThongKe.thongke.getThucDon(maLoaiMon);
        fillToTblById(tbl, list);
    }

    public static void fillToBillTblByID(String maHoaDon, JTable tbl) {
        List<Object[]> list = QLThongKe.thongke.getHoaDonCT(maHoaDon);
        fillToTblById(tbl, list);
    }

    private static int findIndex(String tenMon, DefaultTableModel tblModel) {
        int idx = 0;
        Vector all = tblModel.getDataVector();
//        if(all==null){
        while (idx < all.size()) {
            Vector mon = (Vector) all.elementAt(idx);
            if (mon.elementAt(0).toString().equals(tenMon)) {
                return idx;
            }
            idx++;
        }
        if (idx == all.size()) {
            MsgBox.alert(null, "Không tìm thấy thông tin cần tìm!");
            return 0;
        }
//        }
        return 0;
    }

    public static Object[] getFood(JTable tblThucDon) {
        int index = tblThucDon.getSelectedRow(); // Trả về vị trí được chọn trong bảng
        if (index < 0) {
            MsgBox.alert(null, "Chưa chọn món để thêm vào!");
            return null;
        }
        // "Tên Món", "Số Lượng", "ĐV", "Đơn Giá", "Thành Tiền"
        String tenMon = tblThucDon.getValueAt(index, 0).toString();
        int soLuong = 1;
        String donVi = tblThucDon.getValueAt(index, 1).toString();
        float donGia = Float.parseFloat(tblThucDon.getValueAt(index, 2).toString());
        float thanhTien = (float) donGia * soLuong;
        Object[] row = {tenMon, soLuong, donVi, donGia, thanhTien};
        return row;
    }

    public static void themMon(JTable tblHoaDon, Object[] row) {

        for (int i = 0; i < tblHoaDon.getRowCount(); i++) {
            String testMon = (String) tblHoaDon.getValueAt(i, 0);
            if (String.valueOf(row[0]).equals(testMon)) {
                tangSoLuong(tblHoaDon, i);
                tblHoaDon.setRowSelectionInterval(i, i);
                return;
            }
        }
        DefaultTableModel tblModel = (DefaultTableModel) tblHoaDon.getModel();
        tblModel.addRow(row);

        int idx = findIndex(row[0].toString(), tblModel);
        tblHoaDon.setRowSelectionInterval(idx, idx);
    }

    public static void xoaMon(JTable tblHoaDon) {
        int row = tblHoaDon.getSelectedRow();
        if (row >= 0) {
            DefaultTableModel tblModel = (DefaultTableModel) tblHoaDon.getModel();
            tblModel.removeRow(row); // Xóa khỏi JTable trên form
            if (row >= 0) {
                --row;
            }
            if (row >= 0) {
                tblHoaDon.setRowSelectionInterval(row, row);
            }
        }
    }

    public static float tongHoaDon(JTable tblHoaDon) {
        float sum = 0;
        for (int i = 0; i < tblHoaDon.getRowCount(); i++) {
            sum = sum + (float) tblHoaDon.getValueAt(i, 4);
        }
        return sum;
    }

    public static void tangSoLuong(JTable tblHoaDon, int row) {
        int soLuong = (int) tblHoaDon.getValueAt(row, 1) + 1;
        tblHoaDon.setValueAt(soLuong, row, 1);

        float donGia = (float) tblHoaDon.getValueAt(row, 3);
        float thanhTien = (float) donGia * soLuong;
        tblHoaDon.setValueAt(thanhTien, row, 4);
    }

    public static void giamSoLuong(JTable tblHoaDon) {
        int i = tblHoaDon.getSelectedRow();
        int soLuong = (int) tblHoaDon.getValueAt(i, 1);
        if (soLuong > 1) {
            soLuong = soLuong - 1;
        }
        else if(MsgBox.confirm(null, "Bạn có muốn xóa món này?")){
            xoaMon(tblHoaDon);
            return;
        }
        tblHoaDon.setValueAt(soLuong, i, 1);
        float donGia = (float) tblHoaDon.getValueAt(i, 3);
        float thanhTien = (float) donGia * soLuong;
        tblHoaDon.setValueAt(thanhTien, i, 4);
    }
}
