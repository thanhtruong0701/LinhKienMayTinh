
package controllers;

import dao.LoaiMonDAO;
import dao.MonAnDAO;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import model.LoaiMon;
import model.MonAn;
import utils.MsgBox;

public class QLMonAn {
    
    public static MonAnDAO dao = new MonAnDAO();

    public static void insert(MonAn entity) {
        if (dao.insert(entity) > 0) {
            MsgBox.alert(null, "Thêm mới thành công!");
        } else {
            MsgBox.alert(null, "Thêm mới thất bại!");
        }
    }

    public static void update(MonAn entity) {
        if (dao.update(entity) > 0) {
            MsgBox.alert(null, "Cập nhật thành công!");
        } else {
            MsgBox.alert(null, "Cập nhật thất bại!");
        }
    }

    public static boolean detele(String ma) {
        if (dao.delete(ma)> 0) {
            MsgBox.alert(null, "Xóa thành công!");
            return true;
        } else {
            MsgBox.alert(null, "Xóa thất bại!");
        } 
        return false;
    }
    
    public static void fillToFoodCbo(JComboBox cbo) {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo.getModel();
        model.removeAllElements();
        List<MonAn> list = dao.selectAll();
        model.addElement("Chưa chọn");
        for (MonAn mon : list) {
            model.addElement(mon.getTenMon());
        }
    }
    
    public static void fillToTypesOfFoodCbo(JComboBox cbo) {
        LoaiMonDAO daoLM = new LoaiMonDAO();
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo.getModel();
        model.removeAllElements();
        List<LoaiMon> list = daoLM.selectAll();
        model.addElement("Chưa chọn");
        for (LoaiMon lm : list) {
            model.addElement(lm.getTenLoaiMon());
        }
    }
}
