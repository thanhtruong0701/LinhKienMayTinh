package controllers;

import dao.CaTrucDAO;
import dao.ChucVuDAO;
import dao.NhanVienDAO;
import utils.MsgBox;
import model.CaTruc;
import model.ChucVu;
import model.NhanVien;
import java.awt.HeadlessException;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class QLNhanVien {

    public static NhanVienDAO dao = new NhanVienDAO();
    public static ChucVuDAO daoCV = new ChucVuDAO();
    public static CaTrucDAO daoCT = new CaTrucDAO();

    public static void insert(NhanVien entity) {
        if (dao.insert(entity) > 0) {
            MsgBox.alert(null, "Thêm mới thành công!");
        } else {
            MsgBox.alert(null, "Thêm mới thất bại!");
        }
    }

    public static void update(NhanVien entity) {
        if (dao.update(entity) > 0) {
            MsgBox.alert(null, "Cập nhật thành công!");
        } else {
            MsgBox.alert(null, "Cập nhật thất bại!");
        }
    }

    public static boolean detele(String ma) {
        if (dao.delete(ma) > 0) {
            MsgBox.alert(null, "Xóa thành công!");
            return true;
        } else {
            MsgBox.alert(null, "Xóa thất bại!");
        }
        return false;
    }

    public static void fillToCbo(JComboBox cbo) {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo.getModel();
        model.removeAllElements();
        List<NhanVien> list = dao.selectAll();
        model.addElement("Chưa chọn");
        for (NhanVien nv : list) {
            model.addElement(nv.getHoTenNV());
        }
    }
    
    public static void fillComboBoxNhanVien(JComboBox cbo) {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo.getModel();
        model.removeAllElements();
        List<NhanVien> list = dao.selectAll();
        model.addElement("Chưa chọn");
        for (NhanVien nv : list) {
            model.addElement(nv.getHoTenNV());
        }
    }

    public static void fillComboBoxCatruc(JComboBox cboCaTruc) {
        
        DefaultComboBoxModel model = (DefaultComboBoxModel) cboCaTruc.getModel();
        model.removeAllElements();
        List<CaTruc> list = daoCT.selectAll();
        model.addElement("Chưa chọn");
        for (CaTruc ct : list) {
            model.addElement(ct.getMaCaTruc());
        }
    }
    
    public static void fillComboBox(JComboBox cbo, List<String> values) {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo.getModel();
        model.removeAllElements();
        model.addElement("Chưa chọn");
        for (String value : values) {
            model.addElement(value);
        }
    }

    public static void fillComboBoxChucVu(JComboBox cboChucVu) {
        
        DefaultComboBoxModel model = (DefaultComboBoxModel) cboChucVu.getModel();
        model.removeAllElements();
        List<ChucVu> list = daoCV.selectAll();
        model.addElement("Chưa chọn");
        for (ChucVu cv : list) {
            model.addElement(cv.getChucVu());
        }
    }
    
    public static void fillTableNhanVien(JTable tblNhanVien) {
        DefaultTableModel model = (DefaultTableModel) tblNhanVien.getModel();
        model.setRowCount(0); // Xóa tất cả các hàng trên JTable
        try {
            List<NhanVien> list = dao.selectAll(); // đọc dữ liệu từ CSDL
            for (NhanVien nv : list) {
                // "Mã NV", "Họ Tên NV", "Giới Tính", "Số ĐT", "Địa Chỉ", "Chức Vụ", "Lương", "Mật Khẩu"
                String chucVu = daoCV.selectById(nv.getMaCV()).getChucVu();
                Object[] row = {nv.getMaNV(), nv.getHoTenNV(), nv.getGioiTinh(), nv.getSoDT(), nv.getDiaChi(), chucVu, nv.getLuong(), nv.getMatKhau()};
                model.addRow(row);// Thêm môt hàng vào JTable
            }
        } catch (Exception e) {
            MsgBox.alert(null, "Lỗi truy vấn dữ liệu!");
        }
    }
    
}
