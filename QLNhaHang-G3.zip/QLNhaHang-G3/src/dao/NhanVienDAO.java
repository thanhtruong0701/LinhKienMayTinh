package dao;

import utils.XJdbc;
import model.NhanVien;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDAO extends MainDAO<NhanVien, String> {

    String INSERT_SQL = "INSERT INTO NhanVien (MaNV, MatKhau, HoTenNV, GioiTinh, SoDT, DiaChi, Luong, MaCV, MaCaTruc) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
    String UPDATE_SQL = "UPDATE NhanVien SET MatKhau = ?, HoTenNV = ?, GioiTinh = ?, SoDT = ?, DiaChi = ?, Luong = ?, MaCV = ?, MaCaTruc = ? WHERE MaNV = ?;";
    String DELETE_SQL = "DELETE FROM NhanVien WHERE MaNV = ?;";
    String SELECT_ALL_SQL = "SELECT * FROM NhanVien;";
    String SELECT_BY_ID_SQL = "SELECT * FROM NhanVien WHERE MaNV = ?;";
    String SELECT_BY_NAME_SQL = "SELECT * FROM NhanVien WHERE HoTenNV = ?;";

    @Override
    public int insert(NhanVien entity) {
        Object args[]
                = {
                    entity.getMaNV(),
                    entity.getMatKhau(),
                    entity.getHoTenNV(),
                    entity.getGioiTinh(),
                    entity.getSoDT(),
                    entity.getDiaChi(),
                    entity.getLuong(),
                    entity.getMaCV(),
                    entity.getMaCaTruc()
                };
        return XJdbc.updateData(INSERT_SQL, args);
    }

    @Override
    public int update(NhanVien entity) {
        Object args[]
                = {
                    entity.getMatKhau(),
                    entity.getHoTenNV(),
                    entity.getGioiTinh(),
                    entity.getSoDT(),
                    entity.getDiaChi(),
                    entity.getLuong(),
                    entity.getMaCV(),
                    entity.getMaCaTruc(),
                    entity.getMaNV()
                };
        return XJdbc.updateData(UPDATE_SQL, args);
    }

    @Override
    public int delete(String id) {
        return XJdbc.updateData(DELETE_SQL, id);
    }

    @Override
    public NhanVien selectById(String id) {
        List<NhanVien> list = this.selectBySql(SELECT_BY_ID_SQL, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<NhanVien> selectAll() {
        return this.selectBySql(SELECT_ALL_SQL);
    }

    @Override
    protected List<NhanVien> selectBySql(String sql, Object... args) {
        List<NhanVien> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.queryData(sql, args);
            while (rs.next()) {
                NhanVien entity = new NhanVien();
                entity.setMaNV(rs.getString("MaNV"));
                entity.setMatKhau(rs.getString("MatKhau"));
                entity.setHoTenNV(rs.getString("HoTenNV"));
                entity.setGioiTinh(rs.getString("GioiTinh"));
                entity.setSoDT(rs.getString("SoDT"));
                entity.setDiaChi(rs.getString("DiaChi"));
                entity.setLuong(rs.getFloat("Luong"));
                entity.setMaCV(rs.getString("MaCV"));
                entity.setMaCaTruc(rs.getInt("MaCaTruc"));
                list.add(entity);
            }
//            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception ex) {
            System.out.println("Lỗi selectBySql: " + ex);
            throw new RuntimeException(ex);
        }
    }
    
    public NhanVien selectByName(String name) {
        // Sử dụng được lệnh này với điều kiện, nhân viên không trùng tên
        List<NhanVien> list = this.selectBySql(SELECT_BY_NAME_SQL, name);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }
}
