
package model;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

// implements Serialization

public class CaTruc extends Main {
    
    int maCaTruc;
    Time gioBatDau;
    Time gioKetCa;

    public CaTruc() {
    }

    public CaTruc(int maCaTruc, Time gioBatDau, Time gioKetCa) {
        this.maCaTruc = maCaTruc;
        this.gioBatDau = gioBatDau;
        this.gioKetCa = gioKetCa;
    }
    
    public int getMaCaTruc() {
        return maCaTruc;
    }

    public void setMaCaTruc(int maCaTruc) {
        this.maCaTruc = maCaTruc;
    }

    public Time getGioBatDau() {
        return gioBatDau;
    }

    public void setGioBatDau(Time gioBatDau) {
        this.gioBatDau = gioBatDau;
    }

    public Time getGioKetCa() {
        return gioKetCa;
    }

    public void setGioKetCa(Time gioKetCa) {
        this.gioKetCa = gioKetCa;
    }

}
