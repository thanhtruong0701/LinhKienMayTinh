
package model;

public class ChucVu {
    String maCV;
    String chucVu;

    public ChucVu() {
    }

    public ChucVu(String maCV, String chucVu) {
        this.maCV = maCV;
        this.chucVu = chucVu;
    }

    public String getMaCV() {
        return maCV;
    }

    public void setMaCV(String maCV) {
        this.maCV = maCV;
    }

    public String getChucVu() {
        return chucVu;
    }

    public void setChucVu(String chucVu) {
        this.chucVu = chucVu;
    }
    
}
