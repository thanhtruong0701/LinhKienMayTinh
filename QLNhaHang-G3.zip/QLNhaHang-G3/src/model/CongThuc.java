
package model;

public class CongThuc {
    
    String maMon;
    String maNgLieu;
    String donVi;
    float soLuong;

    public CongThuc() {
    }

    public CongThuc(String maMon, String maNgLieu, String donVi, float soLuong) {
        this.maMon = maMon;
        this.maNgLieu = maNgLieu;
        this.donVi = donVi;
        this.soLuong = soLuong;
    }

    public String getMaMon() {
        return maMon;
    }

    public void setMaMon(String maMon) {
        this.maMon = maMon;
    }

    public String getMaNgLieu() {
        return maNgLieu;
    }

    public void setMaNgLieu(String maNgLieu) {
        this.maNgLieu = maNgLieu;
    }

    public String getDonVi() {
        return donVi;
    }

    public void setDonVi(String donVi) {
        this.donVi = donVi;
    }

    public float getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(float soLuong) {
        this.soLuong = soLuong;
    }
    
}
