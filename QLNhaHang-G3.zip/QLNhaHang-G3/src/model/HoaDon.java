
package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HoaDon {
    int maHoaDon;
    Date ngayLapHD;
    String hinhThucTT;
    String maNV;
    String maKH;

    public HoaDon() {
    }

    public HoaDon(int maHoaDon, Date ngayLapHD, String hinhThucTT, String maNV, String maKH) {
        this.maHoaDon = maHoaDon;
        this.ngayLapHD = ngayLapHD;
        this.hinhThucTT = hinhThucTT;
        this.maNV = maNV;
        this.maKH = maKH;
    }

    public int getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(int maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public Date getNgayLapHD() {
        return ngayLapHD;
    }

    public void setNgayLapHD(Date ngayLapHD) {
        this.ngayLapHD = ngayLapHD;
    }

    public String getHinhThucTT() {
        return hinhThucTT;
    }

    public void setHinhThucTT(String hinhThucTT) {
        this.hinhThucTT = hinhThucTT;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }
    
    public List<String> getEntity()
    {
        List<String> list = new ArrayList<>();
        list.add("MaHoaDon");
        list.add("NgayLapHD");
        list.add("HinhThucTT");
        list.add("MaNV");
        list.add("MaKH");
        return list;
    }
}
