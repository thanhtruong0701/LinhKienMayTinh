
package model;

public class HoaDonCT {
    int maHoaDonCT;
    int maHoaDon;
    String maMon;
    float soLuong;
    String donVi;

    public HoaDonCT() {
    }

    public HoaDonCT(int maHoaDonCT, int maHoaDon, String maMon, float soLuong, String donVi) {
        this.maHoaDonCT = maHoaDonCT;
        this.maHoaDon = maHoaDon;
        this.maMon = maMon;
        this.soLuong = soLuong;
        this.donVi = donVi;
    }
    
    public int getMaHoaDonCT() {
        return maHoaDonCT;
    }

    public void setMaHoaDonCT(int maHoaDonCT) {
        this.maHoaDonCT = maHoaDonCT;
    }

    public int getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(int maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public String getMaMon() {
        return maMon;
    }

    public void setMaMon(String maMon) {
        this.maMon = maMon;
    }

    public float getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(float soLuong) {
        this.soLuong = soLuong;
    }

    public String getDonVi() {
        return donVi;
    }

    public void setDonVi(String donVi) {
        this.donVi = donVi;
    }
    
}
