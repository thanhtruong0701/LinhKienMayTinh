
package model;

import java.util.ArrayList;
import java.util.List;

public class KhachHang {
    
    String hoTenKH;
    String soDT;
    String diaChi;

    public KhachHang() {
    }

    public KhachHang(String hoTenKH, String soDT, String diaChi) {
        this.hoTenKH = hoTenKH;
        this.soDT = soDT;
        this.diaChi = diaChi;
    }

    public String getHoTenKH() {
        return hoTenKH;
    }

    public void setHoTenKH(String hoTenKH) {
        this.hoTenKH = hoTenKH;
    }

    public String getSoDT() {
        return soDT;
    }

    public void setSoDT(String soDT) {
        this.soDT = soDT;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }
    
    public List<String> getEntity()
    {
        List<String> list = new ArrayList<>();
        list.add("HoTenKH");
        list.add("SoDT");
        list.add("DiaChi");
        return list;
    }
}
