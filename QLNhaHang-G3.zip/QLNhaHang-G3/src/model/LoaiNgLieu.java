
package model;

public class LoaiNgLieu {
    String maLoaiNgLieu;
    String tenLoaiNgLieu;

    public LoaiNgLieu() {
    }

    public LoaiNgLieu(String maLoaiNgLieu, String tenLoaiNgLieu) {
        this.maLoaiNgLieu = maLoaiNgLieu;
        this.tenLoaiNgLieu = tenLoaiNgLieu;
    }

    public String getMaLoaiNgLieu() {
        return maLoaiNgLieu;
    }

    public void setMaLoaiNgLieu(String maLoaiNgLieu) {
        this.maLoaiNgLieu = maLoaiNgLieu;
    }

    public String getTenLoaiNgLieu() {
        return tenLoaiNgLieu;
    }

    public void setTenLoaiNgLieu(String tenLoaiNgLieu) {
        this.tenLoaiNgLieu = tenLoaiNgLieu;
    }
    
}
