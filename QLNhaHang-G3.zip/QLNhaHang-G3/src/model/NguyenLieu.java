
package model;

import java.util.ArrayList;
import java.util.List;

public class NguyenLieu {
    
    String maNgLieu;
    String tenNgLieu;
    String donVi;
    float soLuong;
    String maLoaiNgLieu;

    public NguyenLieu() {
    }

    public NguyenLieu(String maNgLieu, String tenNgLieu, String donVi, float soLuong, String maLoaiNgLieu) {
        this.maNgLieu = maNgLieu;
        this.tenNgLieu = tenNgLieu;
        this.donVi = donVi;
        this.soLuong = soLuong;
        this.maLoaiNgLieu = maLoaiNgLieu;
    }

    public String getMaNgLieu() {
        return maNgLieu;
    }

    public void setMaNgLieu(String maNgLieu) {
        this.maNgLieu = maNgLieu;
    }

    public String getTenNgLieu() {
        return tenNgLieu;
    }

    public void setTenNgLieu(String tenNgLieu) {
        this.tenNgLieu = tenNgLieu;
    }

    public String getDonVi() {
        return donVi;
    }

    public void setDonVi(String donVi) {
        this.donVi = donVi;
    }

    public float getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(float soLuong) {
        this.soLuong = soLuong;
    }

    public String getMaLoaiNgLieu() {
        return maLoaiNgLieu;
    }

    public void setMaLoaiNgLieu(String maLoaiNgLieu) {
        this.maLoaiNgLieu = maLoaiNgLieu;
    }
    
    public List<String> getEntity()
    {
        List<String> list = new ArrayList<>();
        list.add("MaNgLieu");
        list.add("TenNgLieu");
        list.add("DonViTinh");
        list.add("SoLuong");
        list.add("MaLoaiNgLieu");
        return list;
    }
}
