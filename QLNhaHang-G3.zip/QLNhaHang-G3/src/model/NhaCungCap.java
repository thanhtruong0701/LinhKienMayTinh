
package model;

public class NhaCungCap {
    String maCC;
    String tenCC;
    String soDT;
    String diaChi;

    public NhaCungCap() {
    }

    public NhaCungCap(String maCC, String tenCC, String soDT, String diaChi) {
        this.maCC = maCC;
        this.tenCC = tenCC;
        this.soDT = soDT;
        this.diaChi = diaChi;
    }

    public String getMaCC() {
        return maCC;
    }

    public void setMaCC(String maCC) {
        this.maCC = maCC;
    }

    public String getTenCC() {
        return tenCC;
    }

    public void setTenCC(String tenCC) {
        this.tenCC = tenCC;
    }

    public String getSoDT() {
        return soDT;
    }

    public void setSoDT(String soDT) {
        this.soDT = soDT;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }
    
}
