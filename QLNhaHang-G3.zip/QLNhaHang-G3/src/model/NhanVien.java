package model;

import java.util.ArrayList;
import java.util.List;

public class NhanVien {

    String maNV;
    String matKhau;
    String hoTenNV;
    String gioiTinh;
    String soDT;
    String diaChi;
    float luong;
    String maCV;
    int maCaTruc;

    public NhanVien() {
    }

    public NhanVien(String maNV, String matKhau, String hoTenNV, String gioiTinh, String soDT, String diaChi, float luong, String maCV, int maCaTruc) {
        this.maNV = maNV;
        this.matKhau = matKhau;
        this.hoTenNV = hoTenNV;
        this.gioiTinh = gioiTinh;
        this.soDT = soDT;
        this.diaChi = diaChi;
        this.luong = luong;
        this.maCV = maCV;
        this.maCaTruc = maCaTruc;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public String getHoTenNV() {
        return hoTenNV;
    }

    public void setHoTenNV(String hoTenNV) {
        this.hoTenNV = hoTenNV;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getSoDT() {
        return soDT;
    }

    public void setSoDT(String soDT) {
        this.soDT = soDT;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public float getLuong() {
        return luong;
    }

    public void setLuong(float luong) {
        this.luong = luong;
    }

    public String getMaCV() {
        return maCV;
    }

    public void setMaCV(String maCV) {
        this.maCV = maCV;
    }

    public int getMaCaTruc() {
        return maCaTruc;
    }

    public void setMaCaTruc(int maCaTruc) {
        this.maCaTruc = maCaTruc;
    }
}
