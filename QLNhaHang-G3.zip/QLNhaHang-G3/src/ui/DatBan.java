
package ui;

import utils.Auth;
import utils.XInit;

/**
 * @author phatdo
 */
public class DatBan extends javax.swing.JFrame {

    public DatBan() {
        initComponents();
        XInit.init(this);
        btnSoDoBan.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnDanhMuc = new javax.swing.JButton();
        btnSoDoBan = new javax.swing.JButton();
        btnDatMon = new javax.swing.JButton();
        btnHuongDan = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnTrong = new javax.swing.JButton();
        btnDatCho = new javax.swing.JButton();
        btnDaDat = new javax.swing.JButton();
        lblTinhTrang = new javax.swing.JLabel();
        btnBan1 = new javax.swing.JButton();
        btnBan2 = new javax.swing.JButton();
        btnBan3 = new javax.swing.JButton();
        btnBan4 = new javax.swing.JButton();
        btnBan5 = new javax.swing.JButton();
        btnBan6 = new javax.swing.JButton();
        btnBan7 = new javax.swing.JButton();
        btnBan8 = new javax.swing.JButton();
        btnBan9 = new javax.swing.JButton();
        btnBan10 = new javax.swing.JButton();
        btnBan11 = new javax.swing.JButton();
        btnBan12 = new javax.swing.JButton();
        btnBan13 = new javax.swing.JButton();
        btnBan14 = new javax.swing.JButton();
        btnBan15 = new javax.swing.JButton();
        btnBan16 = new javax.swing.JButton();
        btnBan17 = new javax.swing.JButton();
        btnBan18 = new javax.swing.JButton();
        btnBan19 = new javax.swing.JButton();
        btnBan20 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));

        btnDanhMuc.setBackground(new java.awt.Color(255, 255, 204));
        btnDanhMuc.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnDanhMuc.setForeground(new java.awt.Color(0, 204, 255));
        btnDanhMuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/purchase-order-32.png"))); // NOI18N
        btnDanhMuc.setText("Danh Mục");
        btnDanhMuc.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 102), 5));
        btnDanhMuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDanhMucActionPerformed(evt);
            }
        });

        btnSoDoBan.setBackground(new java.awt.Color(255, 255, 204));
        btnSoDoBan.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnSoDoBan.setForeground(new java.awt.Color(255, 51, 51));
        btnSoDoBan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-red-32.png"))); // NOI18N
        btnSoDoBan.setText("Đặt Bàn");
        btnSoDoBan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 102), 5));
        btnSoDoBan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSoDoBanActionPerformed(evt);
            }
        });

        btnDatMon.setBackground(new java.awt.Color(255, 255, 204));
        btnDatMon.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnDatMon.setForeground(new java.awt.Color(0, 204, 255));
        btnDatMon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/restaurant-3-32.png"))); // NOI18N
        btnDatMon.setText("Đặt Món");
        btnDatMon.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 102), 5));
        btnDatMon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDatMonActionPerformed(evt);
            }
        });

        btnHuongDan.setBackground(new java.awt.Color(255, 255, 204));
        btnHuongDan.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnHuongDan.setForeground(new java.awt.Color(0, 204, 255));
        btnHuongDan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/help-32.png"))); // NOI18N
        btnHuongDan.setText("Hướng Dẫn");
        btnHuongDan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 102), 5));
        btnHuongDan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuongDanActionPerformed(evt);
            }
        });

        btnExit.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnExit.setForeground(new java.awt.Color(255, 51, 0));
        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/close-window-32.png"))); // NOI18N
        btnExit.setText("THOÁT");
        btnExit.setBorder(null);
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDanhMuc, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btnSoDoBan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnDatMon, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnHuongDan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(btnDanhMuc, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSoDoBan, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDatMon, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnHuongDan)
                .addGap(95, 95, 95)
                .addComponent(btnExit)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnDanhMuc, btnDatMon, btnHuongDan});

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 3, 0, 0, new java.awt.Color(255, 204, 102)));

        btnTrong.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        btnTrong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnTrong.setText("Còn Trống");

        btnDatCho.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        btnDatCho.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-organce-32.png"))); // NOI18N
        btnDatCho.setText("Đã Đặt Chỗ");

        btnDaDat.setBackground(new java.awt.Color(204, 204, 204));
        btnDaDat.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        btnDaDat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-red-32.png"))); // NOI18N
        btnDaDat.setText("Đã Đặt Món");

        lblTinhTrang.setFont(new java.awt.Font("Times New Roman", 3, 30)); // NOI18N
        lblTinhTrang.setForeground(new java.awt.Color(153, 0, 0));
        lblTinhTrang.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTinhTrang.setText("Hiện Tại Nhà Hàng Còn 11 Bàn Trống");

        btnBan1.setBackground(new java.awt.Color(255, 255, 255));
        btnBan1.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan1.setText("Bàn 1");
        btnBan1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan1MouseClicked(evt);
            }
        });

        btnBan2.setBackground(new java.awt.Color(255, 255, 255));
        btnBan2.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan2.setText("Bàn 2");
        btnBan2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan2MouseClicked(evt);
            }
        });

        btnBan3.setBackground(new java.awt.Color(255, 255, 255));
        btnBan3.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan3.setText("Bàn 4");
        btnBan3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan3MouseClicked(evt);
            }
        });

        btnBan4.setBackground(new java.awt.Color(255, 255, 255));
        btnBan4.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-organce-32.png"))); // NOI18N
        btnBan4.setText("Bàn 3");
        btnBan4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan4.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan4MouseClicked(evt);
            }
        });

        btnBan5.setBackground(new java.awt.Color(255, 255, 255));
        btnBan5.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan5.setText("Bàn 5");
        btnBan5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan5.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan5MouseClicked(evt);
            }
        });

        btnBan6.setBackground(new java.awt.Color(255, 255, 255));
        btnBan6.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan6.setText("Bàn 6");
        btnBan6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan6.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan6.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan6MouseClicked(evt);
            }
        });

        btnBan7.setBackground(new java.awt.Color(255, 255, 255));
        btnBan7.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan7.setText("Bàn 7");
        btnBan7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan7.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan7.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan7MouseClicked(evt);
            }
        });

        btnBan8.setBackground(new java.awt.Color(255, 255, 255));
        btnBan8.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-organce-32.png"))); // NOI18N
        btnBan8.setText("Bàn 8");
        btnBan8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan8.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan8.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan8MouseClicked(evt);
            }
        });

        btnBan9.setBackground(new java.awt.Color(255, 255, 255));
        btnBan9.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-red-32.png"))); // NOI18N
        btnBan9.setText("Bàn 9");
        btnBan9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan9.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan9.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan9MouseClicked(evt);
            }
        });

        btnBan10.setBackground(new java.awt.Color(255, 255, 255));
        btnBan10.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan10.setText("Bàn 10");
        btnBan10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan10.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan10.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan10MouseClicked(evt);
            }
        });

        btnBan11.setBackground(new java.awt.Color(255, 255, 255));
        btnBan11.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-red-32.png"))); // NOI18N
        btnBan11.setText("Bàn 11");
        btnBan11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan11.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan11.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan11MouseClicked(evt);
            }
        });

        btnBan12.setBackground(new java.awt.Color(255, 255, 255));
        btnBan12.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan12.setText("Bàn 12");
        btnBan12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan12.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan12.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan12MouseClicked(evt);
            }
        });

        btnBan13.setBackground(new java.awt.Color(255, 255, 255));
        btnBan13.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-red-32.png"))); // NOI18N
        btnBan13.setText("Bàn 13");
        btnBan13.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan13.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan13.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan13MouseClicked(evt);
            }
        });

        btnBan14.setBackground(new java.awt.Color(255, 255, 255));
        btnBan14.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-organce-32.png"))); // NOI18N
        btnBan14.setText("Bàn 14");
        btnBan14.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan14.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan14.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan14MouseClicked(evt);
            }
        });

        btnBan15.setBackground(new java.awt.Color(255, 255, 255));
        btnBan15.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-red-32.png"))); // NOI18N
        btnBan15.setText("Bàn 15");
        btnBan15.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan15.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan15.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan15MouseClicked(evt);
            }
        });

        btnBan16.setBackground(new java.awt.Color(255, 255, 255));
        btnBan16.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-red-32.png"))); // NOI18N
        btnBan16.setText("Bàn 16");
        btnBan16.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan16.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan16.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan16MouseClicked(evt);
            }
        });

        btnBan17.setBackground(new java.awt.Color(255, 255, 255));
        btnBan17.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan17.setText("Bàn 17");
        btnBan17.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan17.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan17.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan17MouseClicked(evt);
            }
        });

        btnBan18.setBackground(new java.awt.Color(255, 255, 255));
        btnBan18.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan18.setText("Bàn 18");
        btnBan18.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan18.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan18.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan18MouseClicked(evt);
            }
        });

        btnBan19.setBackground(new java.awt.Color(255, 255, 255));
        btnBan19.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-organce-32.png"))); // NOI18N
        btnBan19.setText("Bàn 19");
        btnBan19.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan19.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan19.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan19MouseClicked(evt);
            }
        });

        btnBan20.setBackground(new java.awt.Color(255, 255, 255));
        btnBan20.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnBan20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-blue-32.png"))); // NOI18N
        btnBan20.setText("Bàn 20");
        btnBan20.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBan20.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBan20.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBan20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBan20MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblTinhTrang, javax.swing.GroupLayout.PREFERRED_SIZE, 645, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnBan6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnBan1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnBan11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan12, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan13, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan14, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan15, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnBan16, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan17, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan18, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan19, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBan20, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(btnTrong)
                        .addGap(18, 18, 18)
                        .addComponent(btnDatCho, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnDaDat)))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnDaDat, btnDatCho, btnTrong});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnTrong, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnDatCho, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnDaDat, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTinhTrang, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBan1)
                    .addComponent(btnBan2)
                    .addComponent(btnBan4)
                    .addComponent(btnBan3)
                    .addComponent(btnBan5))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBan6)
                    .addComponent(btnBan7)
                    .addComponent(btnBan8)
                    .addComponent(btnBan9)
                    .addComponent(btnBan10))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBan11)
                    .addComponent(btnBan12)
                    .addComponent(btnBan13)
                    .addComponent(btnBan14)
                    .addComponent(btnBan15))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBan16)
                    .addComponent(btnBan17)
                    .addComponent(btnBan18)
                    .addComponent(btnBan19)
                    .addComponent(btnBan20))
                .addGap(23, 23, 23))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnDaDat, btnDatCho, btnTrong});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSoDoBanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSoDoBanActionPerformed
    }//GEN-LAST:event_btnSoDoBanActionPerformed

    private void btnDatMonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDatMonActionPerformed
        new DatMon().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnDatMonActionPerformed

    private void btnHuongDanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuongDanActionPerformed
        // TODO add your handling code here:
        new HuongDan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnHuongDanActionPerformed

    private void btnBan1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan1MouseClicked

    }//GEN-LAST:event_btnBan1MouseClicked

    private void btnBan2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan2MouseClicked

    private void btnBan3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan3MouseClicked

    private void btnBan4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan4MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan4MouseClicked

    private void btnBan5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan5MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan5MouseClicked

    private void btnBan6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan6MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan6MouseClicked

    private void btnBan7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan7MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan7MouseClicked

    private void btnBan8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan8MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan8MouseClicked

    private void btnBan9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan9MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan9MouseClicked

    private void btnBan10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan10MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan10MouseClicked

    private void btnBan11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan11MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan11MouseClicked

    private void btnBan12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan12MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan12MouseClicked

    private void btnBan13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan13MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan13MouseClicked

    private void btnBan14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan14MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan14MouseClicked

    private void btnBan15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan15MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan15MouseClicked

    private void btnBan16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan16MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan16MouseClicked

    private void btnBan17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan17MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan17MouseClicked

    private void btnBan18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan18MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan18MouseClicked

    private void btnBan19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan19MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan19MouseClicked

    private void btnBan20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBan20MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBan20MouseClicked

    private void btnDanhMucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDanhMucActionPerformed
        // TODO add your handling code here:
        String maCV = Auth.user.getMaCV();
        if (Auth.isLogin()) {
            if (null != maCV) {
                switch (maCV) {
                    case "CV001":
                        DanhMucQuanLy quanLy = new DanhMucQuanLy();
                        quanLy.setVisible(true);
                        break;
                    case "CV002":
                        new DanhMucThuNgan().setVisible(true);
                        break;
                    case "CV003":
                        new DanhMucDauBep().setVisible(true);
                        break;
                    default:
                        break;
                }
            }
        }
        this.dispose();
    }//GEN-LAST:event_btnDanhMucActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // TODO add your handling code here:
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnExitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DatBan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DatBan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DatBan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DatBan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DatBan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBan1;
    private javax.swing.JButton btnBan10;
    private javax.swing.JButton btnBan11;
    private javax.swing.JButton btnBan12;
    private javax.swing.JButton btnBan13;
    private javax.swing.JButton btnBan14;
    private javax.swing.JButton btnBan15;
    private javax.swing.JButton btnBan16;
    private javax.swing.JButton btnBan17;
    private javax.swing.JButton btnBan18;
    private javax.swing.JButton btnBan19;
    private javax.swing.JButton btnBan2;
    private javax.swing.JButton btnBan20;
    private javax.swing.JButton btnBan3;
    private javax.swing.JButton btnBan4;
    private javax.swing.JButton btnBan5;
    private javax.swing.JButton btnBan6;
    private javax.swing.JButton btnBan7;
    private javax.swing.JButton btnBan8;
    private javax.swing.JButton btnBan9;
    private javax.swing.JButton btnDaDat;
    private javax.swing.JButton btnDanhMuc;
    private javax.swing.JButton btnDatCho;
    private javax.swing.JButton btnDatMon;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnHuongDan;
    private javax.swing.JButton btnSoDoBan;
    private javax.swing.JButton btnTrong;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblTinhTrang;
    // End of variables declaration//GEN-END:variables
}
