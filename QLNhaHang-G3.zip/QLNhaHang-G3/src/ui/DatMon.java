package ui;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import utils.MsgBox;
import utils.XDate;
import dao.KhachHangDAO;
import dao.LoaiMonDAO;
import model.HoaDon;
import model.HoaDonCT;
import model.KhachHang;
import model.LoaiMon;
import utils.XInit;
import controllers.QLDatMon;
import controllers.QLKhachHang;
import controllers.QLHoaDon;
import controllers.QLHoaDonCT;
import controllers.QLNhanVien;
import controllers.QLThongKe;
import utils.Auth;

public class DatMon extends javax.swing.JFrame {

    HashMap<JButton, String> listButtonName;
    DefaultTableModel tblmodel;
    final String REGEX_SODT = "0\\d{9}";
//    int row = -1;

    // Số Bàn xử lý sau
    // Giờ xử lý sau
    // Phần nhân viên chưa xử lý
    public DatMon() {
        initComponents();
        XInit.init(this);
        this.init();
        QLDatMon.setColsForMenuTable(tblThucDon);
        QLDatMon.setColsForBillTable(tblHoaDon);
        createListBtn();
        fillToTable(btnKhaiVi);
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Date now = new Date();
                        lblClock.setText(XDate.toString(now, "hh:mm:ss aa"));
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        break;
                    }
                }
            }
        }).start();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btnHuongDan = new javax.swing.JButton();
        btnDatMon = new javax.swing.JButton();
        btnSoDoBan = new javax.swing.JButton();
        btnDanhMuc = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        btnKhaiVi = new javax.swing.JButton();
        btnMonSup = new javax.swing.JButton();
        btnHaiSan = new javax.swing.JButton();
        btnMonHeo = new javax.swing.JButton();
        btnMonGa = new javax.swing.JButton();
        btnMonBo = new javax.swing.JButton();
        btnMonRau = new javax.swing.JButton();
        btnGoi = new javax.swing.JButton();
        btnMonLau = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        btnSinhTo = new javax.swing.JButton();
        btnBia = new javax.swing.JButton();
        btnNuocNgot = new javax.swing.JButton();
        btnNuocEp = new javax.swing.JButton();
        pnlHoaDon = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtKhachHang = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtSoDT = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        lblClock = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtDiaChi = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtPhiDichVu = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        txtThue = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        txtTongTien = new javax.swing.JTextField();
        lblNhanVien = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblHoaDon = new javax.swing.JTable();
        lblDate = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        cboPay = new javax.swing.JComboBox<>();
        txtHoaDon = new javax.swing.JTextField();
        txtSoBan = new javax.swing.JTextField();
        btnThanhToan = new javax.swing.JButton();
        btnIn = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        txtTongTien1 = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblThucDon = new javax.swing.JTable();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel8 = new javax.swing.JPanel();
        btnFindKhachHang = new javax.swing.JButton();
        btnResetKhachHang = new javax.swing.JButton();
        btnAddKhachHang = new javax.swing.JButton();
        btnUpdateKhachHang = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        btnAddHoaDon = new javax.swing.JButton();
        btnResetHoaDon = new javax.swing.JButton();
        btnFindHoaDon = new javax.swing.JButton();
        btnUpdateHoaDon = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        btnTang = new javax.swing.JButton();
        btnGiam = new javax.swing.JButton();
        btnThemMon = new javax.swing.JButton();
        btnXoaMon = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.setForeground(new java.awt.Color(255, 255, 51));

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 3, new java.awt.Color(255, 204, 102)));

        btnHuongDan.setBackground(new java.awt.Color(255, 255, 204));
        btnHuongDan.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnHuongDan.setForeground(new java.awt.Color(0, 204, 255));
        btnHuongDan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/help-32.png"))); // NOI18N
        btnHuongDan.setText("Hướng Dẫn");
        btnHuongDan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 102), 5));
        btnHuongDan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuongDanActionPerformed(evt);
            }
        });

        btnDatMon.setBackground(new java.awt.Color(255, 255, 204));
        btnDatMon.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnDatMon.setForeground(new java.awt.Color(0, 204, 255));
        btnDatMon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/restaurant-3-32.png"))); // NOI18N
        btnDatMon.setText("Đặt Món");
        btnDatMon.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 102), 5));

        btnSoDoBan.setBackground(new java.awt.Color(255, 255, 204));
        btnSoDoBan.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnSoDoBan.setForeground(new java.awt.Color(0, 204, 255));
        btnSoDoBan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/table-32.png"))); // NOI18N
        btnSoDoBan.setText("Đặt Bàn");
        btnSoDoBan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 102), 5));
        btnSoDoBan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSoDoBanActionPerformed(evt);
            }
        });

        btnDanhMuc.setBackground(new java.awt.Color(255, 255, 204));
        btnDanhMuc.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnDanhMuc.setForeground(new java.awt.Color(0, 204, 255));
        btnDanhMuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/purchase-order-32.png"))); // NOI18N
        btnDanhMuc.setText("Danh Mục");
        btnDanhMuc.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 204, 102), 5));
        btnDanhMuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDanhMucActionPerformed(evt);
            }
        });

        btnExit.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnExit.setForeground(new java.awt.Color(255, 51, 0));
        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/close-window-32.png"))); // NOI18N
        btnExit.setText("THOÁT");
        btnExit.setBorder(null);
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDanhMuc, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btnSoDoBan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnDatMon, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnHuongDan, javax.swing.GroupLayout.Alignment.TRAILING))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnDanhMuc, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSoDoBan, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDatMon, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnHuongDan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnDanhMuc, btnDatMon, btnHuongDan, btnSoDoBan});

        jTabbedPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTabbedPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel3.setBackground(new java.awt.Color(255, 204, 102));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnKhaiVi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Potatos-icon.png"))); // NOI18N
        btnKhaiVi.setText("Khai Vị");
        btnKhaiVi.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnKhaiVi.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnKhaiVi.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnKhaiVi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKhaiViActionPerformed(evt);
            }
        });

        btnMonSup.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Soup-icon.png"))); // NOI18N
        btnMonSup.setText("Món Súp");
        btnMonSup.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnMonSup.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnMonSup.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnMonSup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMonSupActionPerformed(evt);
            }
        });

        btnHaiSan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Crab-icon.png"))); // NOI18N
        btnHaiSan.setText("Hải Sản");
        btnHaiSan.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnHaiSan.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnHaiSan.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnHaiSan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHaiSanActionPerformed(evt);
            }
        });

        btnMonHeo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Pork-icon.png"))); // NOI18N
        btnMonHeo.setText("Món Heo");
        btnMonHeo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnMonHeo.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnMonHeo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnMonHeo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMonHeoActionPerformed(evt);
            }
        });

        btnMonGa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Chicken-icon.png"))); // NOI18N
        btnMonGa.setText("Món Gà");
        btnMonGa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnMonGa.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnMonGa.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnMonGa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMonGaActionPerformed(evt);
            }
        });

        btnMonBo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Steak-icon.png"))); // NOI18N
        btnMonBo.setText("Món Bò");
        btnMonBo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnMonBo.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnMonBo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnMonBo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMonBoActionPerformed(evt);
            }
        });

        btnMonRau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Fruits-Vegetables-icon.png"))); // NOI18N
        btnMonRau.setText("Món Rau");
        btnMonRau.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnMonRau.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnMonRau.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnMonRau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMonRauActionPerformed(evt);
            }
        });

        btnGoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Salad-icon.png"))); // NOI18N
        btnGoi.setText("Gỏi-Salad");
        btnGoi.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGoi.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnGoi.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGoiActionPerformed(evt);
            }
        });

        btnMonLau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/hot-pot.png"))); // NOI18N
        btnMonLau.setText("Món Lẫu");
        btnMonLau.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnMonLau.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnMonLau.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnMonLau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMonLauActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnMonRau, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                    .addComponent(btnMonBo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                    .addComponent(btnKhaiVi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(btnGoi, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                        .addComponent(btnMonGa, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnMonSup, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnHaiSan, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMonLau, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                    .addComponent(btnMonHeo, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnGoi, btnHaiSan, btnKhaiVi, btnMonBo, btnMonGa, btnMonHeo, btnMonLau, btnMonRau, btnMonSup});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMonSup)
                    .addComponent(btnKhaiVi)
                    .addComponent(btnHaiSan, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMonGa)
                    .addComponent(btnMonHeo, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMonBo))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMonLau)
                    .addComponent(btnMonRau)
                    .addComponent(btnGoi))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnGoi, btnHaiSan, btnKhaiVi, btnMonBo, btnMonGa, btnMonHeo, btnMonLau, btnMonRau, btnMonSup});

        jTabbedPane1.addTab("Món Ăn", jPanel3);

        jPanel5.setBackground(new java.awt.Color(255, 204, 102));

        btnSinhTo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/SinhTo-icon.png"))); // NOI18N
        btnSinhTo.setText("Sinh Tố");
        btnSinhTo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnSinhTo.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnSinhTo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnSinhTo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSinhToActionPerformed(evt);
            }
        });

        btnBia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Beer-icon.png"))); // NOI18N
        btnBia.setText("Các Loại Bia");
        btnBia.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBia.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnBia.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBiaActionPerformed(evt);
            }
        });

        btnNuocNgot.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/7up-icon.png"))); // NOI18N
        btnNuocNgot.setText("Nước Ngọt");
        btnNuocNgot.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnNuocNgot.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnNuocNgot.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnNuocNgot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuocNgotActionPerformed(evt);
            }
        });

        btnNuocEp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/menu/Juice-icon.png"))); // NOI18N
        btnNuocEp.setText("Nước Ép");
        btnNuocEp.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnNuocEp.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnNuocEp.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnNuocEp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuocEpActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnNuocEp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBia, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSinhTo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnNuocNgot, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE))
                .addGap(14, 14, 14))
        );

        jPanel5Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnBia, btnNuocEp, btnNuocNgot, btnSinhTo});

        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBia)
                    .addComponent(btnNuocNgot))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnNuocEp)
                    .addComponent(btnSinhTo))
                .addContainerGap(89, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Thức Uống", jPanel5);

        pnlHoaDon.setBackground(new java.awt.Color(255, 204, 102));
        pnlHoaDon.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hóa Đơn", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 24))); // NOI18N

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Số Hóa Đơn: ");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Khách Hàng:");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("Số Điện Thoại:");

        txtSoDT.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtSoDTCaretUpdate(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setText("Số Bàn:");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("Giờ:");

        lblClock.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblClock.setText("00:00:00");

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("Địa Chỉ:");

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setText("Ngày:");

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setText("Phí DV (5%):");

        txtPhiDichVu.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtPhiDichVu.setText("0.0");

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setText("Thuế VAT (10%):");

        txtThue.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtThue.setText("0.0");

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel22.setText("Tổng Tiền:");

        txtTongTien.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTongTien.setText("0.0");

        lblNhanVien.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblNhanVien.setText("Huỳnh Nhật Cường");

        tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        jScrollPane2.setViewportView(tblHoaDon);

        lblDate.setText("12/01/2022");

        jLabel31.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel31.setText("Nhân Viên:");

        cboPay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tiền Mặt", "Chuyển Khoản", "Cà Thẻ" }));

        txtHoaDon.setHorizontalAlignment(javax.swing.JTextField.LEFT);

        txtSoBan.setHorizontalAlignment(javax.swing.JTextField.LEFT);

        btnThanhToan.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnThanhToan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/card-in-use-32.png"))); // NOI18N
        btnThanhToan.setText("THANH TOÁN");
        btnThanhToan.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThanhToanActionPerformed(evt);
            }
        });

        btnIn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnIn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/printer-32.png"))); // NOI18N
        btnIn.setText("IN HÓA ĐƠN");
        btnIn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setText("Giảm giá:");

        txtTongTien1.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTongTien1.setText("0.0");

        javax.swing.GroupLayout pnlHoaDonLayout = new javax.swing.GroupLayout(pnlHoaDon);
        pnlHoaDon.setLayout(pnlHoaDonLayout);
        pnlHoaDonLayout.setHorizontalGroup(
            pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHoaDonLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(pnlHoaDonLayout.createSequentialGroup()
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlHoaDonLayout.createSequentialGroup()
                                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtKhachHang)
                                    .addComponent(txtSoDT, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE))
                                .addGap(22, 22, 22)
                                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(pnlHoaDonLayout.createSequentialGroup()
                                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblClock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(pnlHoaDonLayout.createSequentialGroup()
                                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(lblDate)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(txtDiaChi)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHoaDonLayout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(txtSoBan))
                    .addGroup(pnlHoaDonLayout.createSequentialGroup()
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnIn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnThanhToan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cboPay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlHoaDonLayout.createSequentialGroup()
                                .addComponent(jLabel31)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHoaDonLayout.createSequentialGroup()
                                .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTongTien1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHoaDonLayout.createSequentialGroup()
                                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtThue, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtPhiDichVu, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap())
        );

        pnlHoaDonLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnIn, btnThanhToan});

        pnlHoaDonLayout.setVerticalGroup(
            pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHoaDonLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(txtSoBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(lblClock))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(txtSoDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19)
                    .addComponent(lblDate))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlHoaDonLayout.createSequentialGroup()
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPhiDichVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtThue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTongTien1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel31)
                            .addComponent(lblNhanVien))
                        .addGap(6, 6, 6))
                    .addGroup(pnlHoaDonLayout.createSequentialGroup()
                        .addComponent(cboPay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                        .addComponent(btnThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnIn, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pnlHoaDonLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnIn, btnThanhToan});

        jPanel7.setBackground(new java.awt.Color(255, 204, 102));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thực Đơn", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        tblThucDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "", "", ""
            }
        ));
        jScrollPane1.setViewportView(tblThucDon);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 278, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel8.setBackground(new java.awt.Color(255, 204, 102));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Khách hàng"));

        btnFindKhachHang.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFindKhachHang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search-9-24.png"))); // NOI18N
        btnFindKhachHang.setText("Tìm kiếm");
        btnFindKhachHang.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFindKhachHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindKhachHangActionPerformed(evt);
            }
        });

        btnResetKhachHang.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnResetKhachHang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new-24.png"))); // NOI18N
        btnResetKhachHang.setText("Làm mới");
        btnResetKhachHang.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnResetKhachHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetKhachHangActionPerformed(evt);
            }
        });

        btnAddKhachHang.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnAddKhachHang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-user-3-24.png"))); // NOI18N
        btnAddKhachHang.setText("Lưu KH");
        btnAddKhachHang.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAddKhachHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddKhachHangActionPerformed(evt);
            }
        });

        btnUpdateKhachHang.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnUpdateKhachHang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/available-updates-24.png"))); // NOI18N
        btnUpdateKhachHang.setText("Cập nhật");
        btnUpdateKhachHang.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnUpdateKhachHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateKhachHangActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFindKhachHang)
                    .addComponent(btnUpdateKhachHang)
                    .addComponent(btnAddKhachHang)
                    .addComponent(btnResetKhachHang))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel8Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAddKhachHang, btnFindKhachHang, btnResetKhachHang, btnUpdateKhachHang});

        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFindKhachHang)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnUpdateKhachHang)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAddKhachHang)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnResetKhachHang)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(255, 204, 102));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Hóa đơn"));

        btnAddHoaDon.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnAddHoaDon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-list-24.png"))); // NOI18N
        btnAddHoaDon.setText("Lưu HĐ");
        btnAddHoaDon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAddHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddHoaDonActionPerformed(evt);
            }
        });

        btnResetHoaDon.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnResetHoaDon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new-24.png"))); // NOI18N
        btnResetHoaDon.setText("Làm mới");
        btnResetHoaDon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnResetHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetHoaDonActionPerformed(evt);
            }
        });

        btnFindHoaDon.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFindHoaDon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search-9-24.png"))); // NOI18N
        btnFindHoaDon.setText("Tìm kiếm");
        btnFindHoaDon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFindHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindHoaDonActionPerformed(evt);
            }
        });

        btnUpdateHoaDon.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnUpdateHoaDon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/available-updates-24.png"))); // NOI18N
        btnUpdateHoaDon.setText("Cập nhật");
        btnUpdateHoaDon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnUpdateHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateHoaDonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnUpdateHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(121, 121, 121))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFindHoaDon)
                    .addComponent(btnAddHoaDon)
                    .addComponent(btnResetHoaDon))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel9Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAddHoaDon, btnFindHoaDon, btnResetHoaDon});

        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFindHoaDon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnUpdateHoaDon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAddHoaDon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnResetHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel10.setBackground(new java.awt.Color(255, 204, 102));
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Thêm món"));

        btnTang.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnTang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/plus-24.png"))); // NOI18N
        btnTang.setText("TĂNG");
        btnTang.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnTang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTangActionPerformed(evt);
            }
        });

        btnGiam.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnGiam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/minus-24.png"))); // NOI18N
        btnGiam.setText("GIẢM");
        btnGiam.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnGiam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGiamActionPerformed(evt);
            }
        });

        btnThemMon.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnThemMon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-list-24.png"))); // NOI18N
        btnThemMon.setText("THÊM");
        btnThemMon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnThemMon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemMonActionPerformed(evt);
            }
        });

        btnXoaMon.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnXoaMon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete-24.png"))); // NOI18N
        btnXoaMon.setText(" XÓA");
        btnXoaMon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnXoaMon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaMonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnThemMon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnXoaMon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGiam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnTang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnThemMon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnXoaMon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnGiam)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTang)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(pnlHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(pnlHoaDon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuocEpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuocEpActionPerformed
        fillToTable(btnNuocEp);
    }//GEN-LAST:event_btnNuocEpActionPerformed

    private void btnNuocNgotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuocNgotActionPerformed
        fillToTable(btnNuocNgot);
    }//GEN-LAST:event_btnNuocNgotActionPerformed

    private void btnBiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBiaActionPerformed
        fillToTable(btnBia);
    }//GEN-LAST:event_btnBiaActionPerformed

    private void btnSinhToActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSinhToActionPerformed
        fillToTable(btnSinhTo);
    }//GEN-LAST:event_btnSinhToActionPerformed

    private void btnMonLauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMonLauActionPerformed
        fillToTable(btnMonLau);
    }//GEN-LAST:event_btnMonLauActionPerformed

    private void btnGoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGoiActionPerformed
        fillToTable(btnGoi);
    }//GEN-LAST:event_btnGoiActionPerformed

    private void btnMonRauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMonRauActionPerformed
        fillToTable(btnMonRau);
    }//GEN-LAST:event_btnMonRauActionPerformed

    private void btnMonBoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMonBoActionPerformed
        fillToTable(btnMonBo);
    }//GEN-LAST:event_btnMonBoActionPerformed

    private void btnMonGaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMonGaActionPerformed
        fillToTable(btnMonGa);
    }//GEN-LAST:event_btnMonGaActionPerformed

    private void btnMonHeoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMonHeoActionPerformed
        fillToTable(btnMonHeo);
    }//GEN-LAST:event_btnMonHeoActionPerformed

    private void btnHaiSanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHaiSanActionPerformed
        fillToTable(btnHaiSan);
    }//GEN-LAST:event_btnHaiSanActionPerformed

    private void btnMonSupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMonSupActionPerformed
        fillToTable(btnMonSup);
    }//GEN-LAST:event_btnMonSupActionPerformed

    private void btnKhaiViActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKhaiViActionPerformed
        fillToTable(btnKhaiVi);
    }//GEN-LAST:event_btnKhaiViActionPerformed

    private void btnFindKhachHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindKhachHangActionPerformed
        // TODO add your handling code here:
        String soDT = (String) MsgBox.prompt(btnFindKhachHang, "Nhập số điện thoại khách hàng cần tìm: ");
        if (soDT != null) {
            this.setFormKhachHang(soDT.trim());
        }
    }//GEN-LAST:event_btnFindKhachHangActionPerformed

    private void btnFindHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindHoaDonActionPerformed
        // TODO add your handling code here:
        String maHD = (String) MsgBox.prompt(btnFindKhachHang, "Nhập số hóa đơn cần tìm: ");
        if (maHD != null) {
            this.setFormHoaDon(maHD.substring(maHD.length() - 1));
        }
        
    }//GEN-LAST:event_btnFindHoaDonActionPerformed

    private void btnUpdateKhachHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateKhachHangActionPerformed
        // TODO add your handling code here:
        QLKhachHang.update(this.getFormKhachHang());
    }//GEN-LAST:event_btnUpdateKhachHangActionPerformed

    private void btnUpdateHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateHoaDonActionPerformed
        // TODO add your handling code here:
        QLHoaDon.update(this.getFormHoaDon());
        for (int i = 0; i < tblHoaDon.getRowCount(); i++) {
            QLHoaDonCT.dao.update(this.getFormHoaDonCT(i));
        }
    }//GEN-LAST:event_btnUpdateHoaDonActionPerformed

    private void btnAddKhachHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddKhachHangActionPerformed
        // TODO add your handling code here:
        QLKhachHang.insert(this.getFormKhachHang());
    }//GEN-LAST:event_btnAddKhachHangActionPerformed

    private void btnAddHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddHoaDonActionPerformed
        // TODO add your handling code here:
        QLHoaDon.insert(this.getFormHoaDon());
        for (int i = 0; i < tblHoaDon.getRowCount(); i++) {
            QLHoaDonCT.insert(this.getFormHoaDonCT(i));
        }
    }//GEN-LAST:event_btnAddHoaDonActionPerformed

    private void btnResetKhachHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetKhachHangActionPerformed
        // TODO add your handling code here:
        this.resetFormKhachHang();
    }//GEN-LAST:event_btnResetKhachHangActionPerformed

    private void btnResetHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetHoaDonActionPerformed
        // TODO add your handling code here:
        this.resetFormHoaDon();
    }//GEN-LAST:event_btnResetHoaDonActionPerformed

    private void btnThemMonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemMonActionPerformed
        // TODO add your handling code here:
        Object[] row = QLDatMon.getFood(tblThucDon);
        QLDatMon.themMon(tblHoaDon, row);
        this.tongHoaDon();
        this.updateStatus();
    }//GEN-LAST:event_btnThemMonActionPerformed

    private void btnXoaMonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaMonActionPerformed
        // TODO add your handling code here:
        QLDatMon.xoaMon(tblHoaDon);
        this.tongHoaDon();
        this.updateStatus();
    }//GEN-LAST:event_btnXoaMonActionPerformed

    private void btnGiamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGiamActionPerformed
        // TODO add your handling code here:
        QLDatMon.giamSoLuong(tblHoaDon);
        this.tongHoaDon();
        this.updateStatus();
    }//GEN-LAST:event_btnGiamActionPerformed

    private void btnTangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTangActionPerformed
        // TODO add your handling code here:
        int row = tblHoaDon.getSelectedRow();
        QLDatMon.tangSoLuong(tblHoaDon, row);
    }//GEN-LAST:event_btnTangActionPerformed

    private void txtSoDTCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtSoDTCaretUpdate
        // TODO add your handling code here:
        KhachHang kh = QLKhachHang.dao.selectById(txtSoDT.getText());
        if(kh != null){
            btnUpdateKhachHang.setEnabled(true);
        }
    }//GEN-LAST:event_txtSoDTCaretUpdate

    private void btnDanhMucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDanhMucActionPerformed
        // TODO add your handling code here:
        new DanhMucThuNgan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnDanhMucActionPerformed

    private void btnSoDoBanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSoDoBanActionPerformed
        // TODO add your handling code here:
        new DatBan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnSoDoBanActionPerformed

    private void btnHuongDanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuongDanActionPerformed
        // TODO add your handling code here:
        new HuongDan().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnHuongDanActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // TODO add your handling code here:
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInActionPerformed
        // TODO add your handling code here:
        MsgBox.alert(this, "Đang phát triển tính năng in hóa đơn!");
    }//GEN-LAST:event_btnInActionPerformed

    private void btnThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThanhToanActionPerformed
        // TODO add your handling code here:
        btnAddHoaDonActionPerformed(evt);
        btnInActionPerformed(evt);
    }//GEN-LAST:event_btnThanhToanActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                if (!Auth.isLogin()) {
                    new Login().setVisible(true);
                    MsgBox.alert(null, "Vui lòng đăng nhập!");
                } else {
                    new DatMon().setVisible(true);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddHoaDon;
    private javax.swing.JButton btnAddKhachHang;
    private javax.swing.JButton btnBia;
    private javax.swing.JButton btnDanhMuc;
    private javax.swing.JButton btnDatMon;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnFindHoaDon;
    private javax.swing.JButton btnFindKhachHang;
    private javax.swing.JButton btnGiam;
    private javax.swing.JButton btnGoi;
    private javax.swing.JButton btnHaiSan;
    private javax.swing.JButton btnHuongDan;
    private javax.swing.JButton btnIn;
    private javax.swing.JButton btnKhaiVi;
    private javax.swing.JButton btnMonBo;
    private javax.swing.JButton btnMonGa;
    private javax.swing.JButton btnMonHeo;
    private javax.swing.JButton btnMonLau;
    private javax.swing.JButton btnMonRau;
    private javax.swing.JButton btnMonSup;
    private javax.swing.JButton btnNuocEp;
    private javax.swing.JButton btnNuocNgot;
    private javax.swing.JButton btnResetHoaDon;
    private javax.swing.JButton btnResetKhachHang;
    private javax.swing.JButton btnSinhTo;
    private javax.swing.JButton btnSoDoBan;
    private javax.swing.JButton btnTang;
    private javax.swing.JButton btnThanhToan;
    private javax.swing.JButton btnThemMon;
    private javax.swing.JButton btnUpdateHoaDon;
    private javax.swing.JButton btnUpdateKhachHang;
    private javax.swing.JButton btnXoaMon;
    private javax.swing.JComboBox<String> cboPay;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblClock;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblNhanVien;
    private javax.swing.JPanel pnlHoaDon;
    private javax.swing.JTable tblHoaDon;
    private javax.swing.JTable tblThucDon;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtHoaDon;
    private javax.swing.JTextField txtKhachHang;
    private javax.swing.JTextField txtPhiDichVu;
    private javax.swing.JTextField txtSoBan;
    private javax.swing.JTextField txtSoDT;
    private javax.swing.JTextField txtThue;
    private javax.swing.JTextField txtTongTien;
    private javax.swing.JTextField txtTongTien1;
    // End of variables declaration//GEN-END:variables

    void init() {
        int soHD = (int) QLThongKe.thongke.getSoHoaDon() + 1;
        txtHoaDon.setText("HD00" + soHD);
        lblDate.setText(XDate.toString(new Date(), "dd/MM/yyyy"));
        lblNhanVien.setText(Auth.user.getHoTenNV());
        tblmodel = (DefaultTableModel) tblHoaDon.getModel();
        tblmodel.setRowCount(0);
        btnUpdateKhachHang.setEnabled(false);
        btnUpdateHoaDon.setEnabled(false);
        btnDatMon.setEnabled(false);
        updateStatus();
    }

    private void createListBtn() {
        listButtonName = new HashMap<>();
        JButton[] btn
                = {
                    btnKhaiVi, btnMonSup, btnMonRau, btnGoi,
                    btnMonBo, btnMonGa, btnMonHeo, btnHaiSan, btnMonLau,
                    btnBia, btnNuocNgot, btnSinhTo, btnNuocEp
                };
        LoaiMonDAO dao = new LoaiMonDAO();
        List<LoaiMon> loaiMon = dao.selectAll();
        if (btn.length == loaiMon.size()) {
            for (int i = 0; i < btn.length; i++) {
                listButtonName.put(btn[i], loaiMon.get(i).getMaLoaiMon());
            }
        } else {
            MsgBox.alert(this, "Số lượng loại món và nút nhấn khác nhau! Vui lòng kiểm tra lại!");
        }
    }

    void fillToTable(JButton btn) {
        String maLoaiMon = listButtonName.get(btn);
        QLDatMon.fillToMenuTblById(maLoaiMon, tblThucDon);
    }
    
    

//    boolean checkBeforeDelete() {
//        if (!Auth.isManager()) {
//            MsgBox.alert(this, "Bạn không có quyền xóa thông tin khách hàng!");
//        } else {
//            String manv = txtMaNV.getText();
//
//            if (manv.equals(Auth.user.getMaNV())) {
//                MsgBox.alert(this, "Ban không được xóa chính bạn!");
//            } else {
//                return MsgBox.confirm(this, "Bạn thật sự muốn xóa nhân viên này?");
//            }
//        }
//        return false;
//    }
    
    void resetFormKhachHang() {
        txtKhachHang.setText("");
        txtSoDT.setText("");
        txtDiaChi.setText("");
        txtSoDT.requestFocus();
    }

    void setFormKhachHang(String soDT) {
        KhachHang kh = QLKhachHang.dao.selectById(soDT);
        if (kh != null) {
            txtKhachHang.setText(kh.getHoTenKH());
            txtSoDT.setText(kh.getSoDT());
            txtDiaChi.setText(kh.getDiaChi());
        } else {
            MsgBox.alert(this, "Không tìm thấy thông tin khách hàng!");
        }
    }

    void resetFormHoaDon() {
        init();
        txtKhachHang.setText("");
        txtSoDT.setText("");
        txtDiaChi.setText("");
        txtPhiDichVu.setText("");
        txtThue.setText("");
        txtTongTien.setText("");
        cboPay.setSelectedIndex(0);

        txtSoDT.requestFocus();
    }

    void setFormHoaDon(String maHoaDon) {
        Object[] hd = QLThongKe.thongke.getHoaDon(maHoaDon);
        if (hd != null) {
            // "MaHoaDon", "NgayLapHD", "HinhThucTT", "MaNV", "HoTenNV", "HoTenKH", "SoDT", "DiaChi"
            txtHoaDon.setText("HD00" + hd[0]);
            lblClock.setText(XDate.toString((Date) hd[1], "hh:mm:ss aa"));
            lblDate.setText(XDate.toString((Date) hd[1], "dd-MM-yyyy"));
            cboPay.setSelectedItem(hd[2]);
            lblNhanVien.setText(hd[4].toString());
            txtKhachHang.setText(hd[5].toString());
            txtSoDT.setText(hd[6].toString());
            txtDiaChi.setText(hd[7].toString());
            btnUpdateHoaDon.setEnabled(true);
        } else {
            MsgBox.alert(this, "Không tìm thấy thông tin hóa đơn!");
            this.resetFormHoaDon();
            return;
        }
        QLDatMon.fillToBillTblByID(maHoaDon, tblHoaDon);
        tongHoaDon();
    }

    KhachHang getFormKhachHang() {
        KhachHang entity = new KhachHang();
        entity.setHoTenKH(txtKhachHang.getText().trim());
        entity.setSoDT(txtSoDT.getText().trim());
        entity.setDiaChi(txtDiaChi.getText().trim());
        return entity;
    }

    HoaDon getFormHoaDon() {
        HoaDon entity = new HoaDon();
        String maHD = txtHoaDon.getText();
        entity.setMaHoaDon(Integer.parseInt(maHD.substring(maHD.length() - 1)));
        entity.setMaKH(txtSoDT.getText().trim());
        String maNV = QLNhanVien.dao.selectByName(txtKhachHang.getText().trim()).getMaNV();
        entity.setMaNV(maNV);
        entity.setNgayLapHD(XDate.toDate(lblDate.getText(), "yyyy-MM-dd"));
        entity.setHinhThucTT(cboPay.getSelectedItem().toString());
        return entity;
    }

    HoaDonCT getFormHoaDonCT(int i) {
        HoaDonCT entity = new HoaDonCT();
        String maHD = txtHoaDon.getText();
        entity.setMaHoaDon(Integer.parseInt(maHD.substring(maHD.length() - 1)));
        entity.setMaMon(tblHoaDon.getValueAt(i, 0).toString());
        entity.setDonVi(tblHoaDon.getValueAt(i, 1).toString());
        entity.setSoLuong(Float.parseFloat(tblHoaDon.getValueAt(i, 2).toString()));

        return entity;
    }

    /**
     * Khi tìm thông tin hóa đơn, trong chi tiết hóa đơn sẽ có cả thông tin
     * khách hàng và nhân viên handle khi tìm thấy hóa đơn, sẽ kiểm tra xem phần
     * khách hàng có đang rỗng ko, nếu rỗng thì gán thông tin khách hàng trong
     * hóa đơn chi tiết vào hóa đơn, nếu không rỗng, ktra thông tin khách hàng
     * trong hóa đơn đang tìm có trùng khớp không, hỏi cho người dùng confirm,
     * [OK] là gán toàn bộ, [CANCEL] bỏ qua lệnh gán Đối với ngày lặp hóa đơn,
     * tạm thời chỉ xử lý phần ngày, giờ sẽ không đổi, vẫn theo giờ hệ thống
     *
     */
    void tongHoaDon() {
        float sum = QLDatMon.tongHoaDon(tblHoaDon);
        txtPhiDichVu.setText(String.valueOf(sum * 0.05));
        txtThue.setText(String.valueOf(sum * 0.1));
        txtTongTien.setText(String.valueOf(sum * 0.05 + sum * 0.1 + sum));
    }

    void updateStatus() {
        int row = tblHoaDon.getSelectedRow();
        boolean edit = (row >= 0);
        if (edit) {
            btnXoaMon.setEnabled(true);
            btnTang.setEnabled(true);
            btnGiam.setEnabled(true);
        } else {
            btnXoaMon.setEnabled(false);
            btnTang.setEnabled(false);
            btnGiam.setEnabled(false);
        }
    }
}
