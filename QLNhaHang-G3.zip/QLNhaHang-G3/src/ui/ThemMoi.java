package ui;

import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import utils.XDate;
import utils.XInit;
import controllers.QLCongThuc;
import controllers.QLMonAn;
import controllers.QLNguyenLieu;
import controllers.QLNhanVien;
import controllers.QLPhieuNhap;
import controllers.QLPhieuNhapCT;
import dao.NhanVienDAO;
import dao.ChucVuDAO;
import dao.MonAnDAO;
import dao.LoaiMonDAO;
import dao.PhieuNhapCTDAO;
import dao.PhieuNhapDAO;
import dao.NhaCungCapDAO;
import dao.NguyenLieuDAO;
import dao.LoaiNgLieuDAO;
import dao.CongThucDAO;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import model.NhanVien;
import model.MonAn;
import model.LoaiNgLieu;
import model.NguyenLieu;
import model.PhieuNhap;
import model.PhieuNhapCT;
import model.CongThuc;
import utils.Auth;
import utils.MsgBox;
import utils.XImage;

public class ThemMoi extends javax.swing.JFrame {

    public ThemMoi() {
        initComponents();
        XInit.init(this);
        fillComboBox();
//        // Phan Quyen
//        if (!Auth.isManager()) {
//            tabs.remove(0);
//            tabs.remove(0);
//            tabs.remove(0);
//            if (Auth.user.getMaCV().toString().equals("CV002")) {
//                tabs.remove(1);
//                tabs.remove(1);
//                tabs.remove(1);
//            } else if (Auth.user.getMaCV().toString().equals("CV003")) {
//                tabs.remove(0);
//            }
//        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGroupGender = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        tabs = new javax.swing.JTabbedPane();
        pnlNhanvien = new javax.swing.JPanel();
        pnlFormNhanVien = new javax.swing.JPanel();
        lblMaNV = new javax.swing.JLabel();
        txtMaNV = new javax.swing.JTextField();
        txtHoTen = new javax.swing.JTextField();
        lblHoTen = new javax.swing.JLabel();
        rdoNam = new javax.swing.JRadioButton();
        rdoNu = new javax.swing.JRadioButton();
        txtSoDT = new javax.swing.JTextField();
        lblSoDT = new javax.swing.JLabel();
        lblDiaChi = new javax.swing.JLabel();
        txtDiaChi = new javax.swing.JTextField();
        lblChucVu = new javax.swing.JLabel();
        cboChucVu = new javax.swing.JComboBox<>();
        lblCaTruc = new javax.swing.JLabel();
        cboCaTruc = new javax.swing.JComboBox<>();
        lblLuong = new javax.swing.JLabel();
        txtLuong = new javax.swing.JTextField();
        lblPass = new javax.swing.JLabel();
        txtPass = new javax.swing.JTextField();
        pnlCtrlFormNhanVien = new javax.swing.JPanel();
        btnResetNhanVien = new javax.swing.JButton();
        lblHinhNhanVien = new javax.swing.JLabel();
        btnAddNhanVien = new javax.swing.JButton();
        btnUpdateNhanVien = new javax.swing.JButton();
        btnDeleteNhanVien = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnFindNhanVien = new javax.swing.JButton();
        cboFindNhanVien = new javax.swing.JComboBox<>();
        btnPreNhanVien = new javax.swing.JButton();
        btnNextNhanVien = new javax.swing.JButton();
        btnFirstNhanVien = new javax.swing.JButton();
        btnLastNhanVien = new javax.swing.JButton();
        lblTitleNV = new javax.swing.JLabel();
        pnlMonAn = new javax.swing.JPanel();
        pnlFormMonAn = new javax.swing.JPanel();
        lblMaMon = new javax.swing.JLabel();
        txtMaMon = new javax.swing.JTextField();
        lblTenMon = new javax.swing.JLabel();
        txtTenMon = new javax.swing.JTextField();
        lblDonVi = new javax.swing.JLabel();
        txtDonVi = new javax.swing.JTextField();
        lblLoaiMon = new javax.swing.JLabel();
        cboLoaiMon = new javax.swing.JComboBox<>();
        lblDonGia = new javax.swing.JLabel();
        txtDonGia = new javax.swing.JTextField();
        lblHinhMonAn = new javax.swing.JLabel();
        pnlCtrlFormMonAn = new javax.swing.JPanel();
        btnAddMonAn = new javax.swing.JButton();
        btnDeleteMonAn = new javax.swing.JButton();
        btnUpdateMonAn = new javax.swing.JButton();
        btnResetMonAn = new javax.swing.JButton();
        pnlCtrlDieuHuong1 = new javax.swing.JPanel();
        btnFirstMonAn = new javax.swing.JButton();
        btnPreMonAn = new javax.swing.JButton();
        btnNextMonAn = new javax.swing.JButton();
        btnLastMonAn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        btnFindMonAn = new javax.swing.JButton();
        cboFindMonAn = new javax.swing.JComboBox<>();
        cboFindMonAn1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        pnlPhieuNhap = new javax.swing.JPanel();
        pnlFormPhieuNhap = new javax.swing.JPanel();
        lblMaPhieuNhap = new javax.swing.JLabel();
        txtMaPhieuNhap = new javax.swing.JTextField();
        lblNgayLapPhieu = new javax.swing.JLabel();
        txtNgayLapPhieu = new javax.swing.JTextField();
        lblNgayNhap = new javax.swing.JLabel();
        txtNgayNhap = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        btnUpdatePhieuNhap = new javax.swing.JButton();
        btnDeletePhieuNhap = new javax.swing.JButton();
        btnAddPhieuNhap = new javax.swing.JButton();
        btnResetPhieuNhap = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        btnFindPhieuNhap = new javax.swing.JButton();
        cboFindPhieuNhap = new javax.swing.JComboBox<>();
        btnFirstPhieuNhap = new javax.swing.JButton();
        btnPrePhieuNhap = new javax.swing.JButton();
        btnNextPhieuNhap = new javax.swing.JButton();
        btnLastPhieuNhap = new javax.swing.JButton();
        lblNguoiNhap = new javax.swing.JLabel();
        cboNguoiNhap = new javax.swing.JComboBox<>();
        lblNhaCungCap = new javax.swing.JLabel();
        cboNhaCungCap = new javax.swing.JComboBox<>();
        lblQLNhanVien = new javax.swing.JLabel();
        pnlFormPhieuNhapCT = new javax.swing.JPanel();
        lblMaPhieuNhap2 = new javax.swing.JLabel();
        cboMaPhieuNhap = new javax.swing.JComboBox<>();
        txtDonGiaNgLieu = new javax.swing.JTextField();
        lblTenNguyenLieu2 = new javax.swing.JLabel();
        cboTenNguyenLieu = new javax.swing.JComboBox<>();
        lblDonGiaNgLieu = new javax.swing.JLabel();
        lblDonViNgLieu = new javax.swing.JLabel();
        txtDonViNgLieu = new javax.swing.JTextField();
        lblSoLuongNgLieu = new javax.swing.JLabel();
        txtSoLuongNgLieu = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        btnUpdatePhieuNhapCT = new javax.swing.JButton();
        btnDeletePhieuNhapCT = new javax.swing.JButton();
        btnAddPhieuNhapCT = new javax.swing.JButton();
        btnResetPhieuNhapCT = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        btnFindPhieuNhapCT = new javax.swing.JButton();
        cboFindPhieuNhapCT = new javax.swing.JComboBox<>();
        btnLastPhieuNhapCT = new javax.swing.JButton();
        btnNextPhieuNhapCT = new javax.swing.JButton();
        btnPrePhieuNhapCT = new javax.swing.JButton();
        btnFirstPhieuNhapCT = new javax.swing.JButton();
        pnlNguyenLieu = new javax.swing.JPanel();
        pnlFormMonAn1 = new javax.swing.JPanel();
        lblMaNgLieu = new javax.swing.JLabel();
        txtTenNgLieu = new javax.swing.JTextField();
        lblTenNguyenLieu = new javax.swing.JLabel();
        txtDonViNguyenLieu = new javax.swing.JTextField();
        lblLoaiNguyenLieu = new javax.swing.JLabel();
        lblDonViNguyenLieu = new javax.swing.JLabel();
        lblSoLuongNguyenLieu = new javax.swing.JLabel();
        cboLoaiNguyenLieu = new javax.swing.JComboBox<>();
        txtSoLuongNguyenLieu = new javax.swing.JTextField();
        txtMaNgLieu = new javax.swing.JTextField();
        lblHinhNguyenLieu = new javax.swing.JLabel();
        pnlCtrlFormMonAn1 = new javax.swing.JPanel();
        btnAddNguyenLieu = new javax.swing.JButton();
        btnDeleteNguyenLieu = new javax.swing.JButton();
        btnUpdateNguyenLieu = new javax.swing.JButton();
        btnResetNguyenLieu = new javax.swing.JButton();
        pnlCtrlDieuHuong2 = new javax.swing.JPanel();
        btnFirstNguyenLieu = new javax.swing.JButton();
        btnPreNguyenLieu = new javax.swing.JButton();
        btnNextNguyenLieu = new javax.swing.JButton();
        btnLastNguyenLieu = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        btnFindNguyenLieu = new javax.swing.JButton();
        cboFindNguyenLieu = new javax.swing.JComboBox<>();
        pnlCongThuc = new javax.swing.JPanel();
        pnlFormCongThuc = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        txtMaMonAuto = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        txtDonViAuto = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        cboTenMon = new javax.swing.JComboBox<>();
        jLabel58 = new javax.swing.JLabel();
        cboNguyenLieu = new javax.swing.JComboBox<>();
        txtSoLuong = new javax.swing.JTextField();
        lblHinhCongThuc = new javax.swing.JLabel();
        pnlCtrlFormCongThuc = new javax.swing.JPanel();
        btnDeleteCongThuc = new javax.swing.JButton();
        btnAddCongThuc = new javax.swing.JButton();
        btnResetCongThuc = new javax.swing.JButton();
        btnUpdateCongThuc = new javax.swing.JButton();
        pnlCtrlDieuHuong = new javax.swing.JPanel();
        btnFirstCongThuc = new javax.swing.JButton();
        btnPreCongThuc = new javax.swing.JButton();
        btnNextCongThuc = new javax.swing.JButton();
        btnLastCongThuc = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        mnbarThemMoi = new javax.swing.JMenuBar();
        mnDanhmuc = new javax.swing.JMenu();
        mnThemmoi = new javax.swing.JMenu();
        mnThongke = new javax.swing.JMenu();
        mnExit = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Quản Lý Nhà Hàng");
        setName(""); // NOI18N
        setResizable(false);
        setSize(new java.awt.Dimension(721, 406));

        tabs.setBackground(new java.awt.Color(255, 255, 204));
        tabs.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        tabs.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tabs.setMaximumSize(new java.awt.Dimension(546, 332));
        tabs.setMinimumSize(new java.awt.Dimension(546, 332));

        pnlNhanvien.setBackground(new java.awt.Color(255, 255, 204));

        pnlFormNhanVien.setBackground(new java.awt.Color(255, 220, 126));

        lblMaNV.setText("Mã nhân viên");

        lblHoTen.setText("Họ và tên");

        btnGroupGender.add(rdoNam);
        rdoNam.setSelected(true);
        rdoNam.setText("Nam");

        btnGroupGender.add(rdoNu);
        rdoNu.setText("Nữ");

        lblSoDT.setText("Số điện thoại");

        lblDiaChi.setText("Địa chỉ");

        lblChucVu.setText("Chức vụ");

        lblCaTruc.setText("Ca trực");

        lblLuong.setText("Lương");

        lblPass.setText("Mật Khẩu");

        javax.swing.GroupLayout pnlFormNhanVienLayout = new javax.swing.GroupLayout(pnlFormNhanVien);
        pnlFormNhanVien.setLayout(pnlFormNhanVienLayout);
        pnlFormNhanVienLayout.setHorizontalGroup(
            pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlFormNhanVienLayout.createSequentialGroup()
                .addGap(0, 20, Short.MAX_VALUE)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblHoTen, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblMaNV, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblSoDT, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblDiaChi, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblChucVu, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblCaTruc, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblLuong, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblPass, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtSoDT)
                    .addGroup(pnlFormNhanVienLayout.createSequentialGroup()
                        .addComponent(rdoNam)
                        .addGap(39, 39, 39)
                        .addComponent(rdoNu))
                    .addComponent(txtHoTen)
                    .addComponent(cboCaTruc, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtLuong)
                    .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPass, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );

        pnlFormNhanVienLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtDiaChi, txtHoTen, txtLuong, txtMaNV, txtPass, txtSoDT});

        pnlFormNhanVienLayout.setVerticalGroup(
            pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormNhanVienLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMaNV))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblHoTen)
                    .addComponent(txtHoTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdoNam)
                    .addComponent(rdoNu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSoDT)
                    .addComponent(txtSoDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDiaChi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblChucVu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboCaTruc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCaTruc))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLuong)
                    .addComponent(txtLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPass)
                    .addComponent(txtPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        pnlFormNhanVienLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtHoTen, txtLuong, txtMaNV, txtPass, txtSoDT});

        pnlCtrlFormNhanVien.setBackground(new java.awt.Color(255, 255, 204));
        pnlCtrlFormNhanVien.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnResetNhanVien.setBackground(new java.awt.Color(51, 153, 255));
        btnResetNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnResetNhanVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new-32.png"))); // NOI18N
        btnResetNhanVien.setText("Làm mới");
        btnResetNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetNhanVienActionPerformed(evt);
            }
        });

        lblHinhNhanVien.setBackground(new java.awt.Color(204, 204, 204));
        lblHinhNhanVien.setForeground(new java.awt.Color(255, 51, 51));
        lblHinhNhanVien.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHinhNhanVien.setText("Hình ảnh");
        lblHinhNhanVien.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblHinhNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHinhNhanVienMouseClicked(evt);
            }
        });

        btnAddNhanVien.setBackground(new java.awt.Color(51, 153, 255));
        btnAddNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnAddNhanVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-user-3-32.png"))); // NOI18N
        btnAddNhanVien.setText("Thêm");
        btnAddNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNhanVienActionPerformed(evt);
            }
        });

        btnUpdateNhanVien.setBackground(new java.awt.Color(51, 153, 255));
        btnUpdateNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnUpdateNhanVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/available-updates-32.png"))); // NOI18N
        btnUpdateNhanVien.setText("Chỉnh sửa");
        btnUpdateNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateNhanVienActionPerformed(evt);
            }
        });

        btnDeleteNhanVien.setBackground(new java.awt.Color(51, 153, 255));
        btnDeleteNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnDeleteNhanVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete-32.png"))); // NOI18N
        btnDeleteNhanVien.setText("Xóa");
        btnDeleteNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteNhanVienActionPerformed(evt);
            }
        });

        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnFindNhanVien.setText("Tìm Kiếm");
        btnFindNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindNhanVienActionPerformed(evt);
            }
        });

        cboFindNhanVien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFindNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cboFindNhanVien, 0, 166, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFindNhanVien)
                    .addComponent(cboFindNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnPreNhanVien.setBackground(new java.awt.Color(51, 153, 255));
        btnPreNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnPreNhanVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/previous-32.png"))); // NOI18N
        btnPreNhanVien.setText("Previous");
        btnPreNhanVien.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPreNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreNhanVienActionPerformed(evt);
            }
        });

        btnNextNhanVien.setBackground(new java.awt.Color(51, 153, 255));
        btnNextNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnNextNhanVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/next-32.png"))); // NOI18N
        btnNextNhanVien.setText("Next");
        btnNextNhanVien.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnNextNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextNhanVienActionPerformed(evt);
            }
        });

        btnFirstNhanVien.setBackground(new java.awt.Color(51, 153, 255));
        btnFirstNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnFirstNhanVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/first-32.png"))); // NOI18N
        btnFirstNhanVien.setText("Fisrt");
        btnFirstNhanVien.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFirstNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstNhanVienActionPerformed(evt);
            }
        });

        btnLastNhanVien.setBackground(new java.awt.Color(51, 153, 255));
        btnLastNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnLastNhanVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/last-32.png"))); // NOI18N
        btnLastNhanVien.setText("Last");
        btnLastNhanVien.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLastNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastNhanVienActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlCtrlFormNhanVienLayout = new javax.swing.GroupLayout(pnlCtrlFormNhanVien);
        pnlCtrlFormNhanVien.setLayout(pnlCtrlFormNhanVienLayout);
        pnlCtrlFormNhanVienLayout.setHorizontalGroup(
            pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlFormNhanVienLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlCtrlFormNhanVienLayout.createSequentialGroup()
                        .addGroup(pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnResetNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnUpdateNhanVien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(24, 24, 24)
                        .addGroup(pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAddNhanVien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnDeleteNhanVien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlCtrlFormNhanVienLayout.createSequentialGroup()
                        .addGroup(pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(pnlCtrlFormNhanVienLayout.createSequentialGroup()
                                .addGroup(pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnPreNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnNextNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnFirstNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnLastNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(20, 20, 20)
                                .addComponent(lblHinhNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15))))
        );

        pnlCtrlFormNhanVienLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAddNhanVien, btnDeleteNhanVien, btnResetNhanVien, btnUpdateNhanVien});

        pnlCtrlFormNhanVienLayout.setVerticalGroup(
            pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlFormNhanVienLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlCtrlFormNhanVienLayout.createSequentialGroup()
                        .addComponent(btnPreNhanVien)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNextNhanVien)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnFirstNhanVien)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLastNhanVien))
                    .addComponent(lblHinhNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addGroup(pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnResetNhanVien)
                    .addComponent(btnAddNhanVien))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlFormNhanVienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDeleteNhanVien)
                    .addComponent(btnUpdateNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlCtrlFormNhanVienLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnAddNhanVien, btnDeleteNhanVien, btnResetNhanVien, btnUpdateNhanVien});

        lblTitleNV.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        lblTitleNV.setText("QUẢN LÝ NHÂN VIÊN");

        javax.swing.GroupLayout pnlNhanvienLayout = new javax.swing.GroupLayout(pnlNhanvien);
        pnlNhanvien.setLayout(pnlNhanvienLayout);
        pnlNhanvienLayout.setHorizontalGroup(
            pnlNhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNhanvienLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(pnlNhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitleNV)
                    .addGroup(pnlNhanvienLayout.createSequentialGroup()
                        .addComponent(pnlFormNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pnlCtrlFormNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        pnlNhanvienLayout.setVerticalGroup(
            pnlNhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNhanvienLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblTitleNV)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlNhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(pnlCtrlFormNhanVien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlFormNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(51, Short.MAX_VALUE))
        );

        tabs.addTab("Nhân Viên", pnlNhanvien);

        pnlMonAn.setBackground(new java.awt.Color(255, 255, 204));

        pnlFormMonAn.setBackground(new java.awt.Color(255, 220, 126));

        lblMaMon.setText("Mã Món");

        txtMaMon.setForeground(new java.awt.Color(204, 204, 204));

        lblTenMon.setText("Tên Món");

        txtTenMon.setForeground(new java.awt.Color(204, 204, 204));

        lblDonVi.setText("Đơn Vị");

        lblLoaiMon.setText("Loai Món");

        lblDonGia.setText("Đơn Giá");

        javax.swing.GroupLayout pnlFormMonAnLayout = new javax.swing.GroupLayout(pnlFormMonAn);
        pnlFormMonAn.setLayout(pnlFormMonAnLayout);
        pnlFormMonAnLayout.setHorizontalGroup(
            pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormMonAnLayout.createSequentialGroup()
                .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFormMonAnLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblMaMon)
                            .addComponent(lblDonVi)
                            .addComponent(lblDonGia)
                            .addComponent(lblLoaiMon, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlFormMonAnLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblTenMon)))
                .addGap(18, 18, 18)
                .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtDonGia)
                        .addComponent(txtDonVi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cboLoaiMon, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txtTenMon, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtMaMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        pnlFormMonAnLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cboLoaiMon, txtDonGia, txtDonVi, txtMaMon, txtTenMon});

        pnlFormMonAnLayout.setVerticalGroup(
            pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormMonAnLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMaMon)
                    .addComponent(txtMaMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTenMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTenMon))
                .addGap(17, 17, 17)
                .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboLoaiMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLoaiMon))
                .addGap(18, 18, 18)
                .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDonVi)
                    .addComponent(txtDonVi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDonGia)
                    .addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        lblHinhMonAn.setBackground(new java.awt.Color(204, 204, 204));
        lblHinhMonAn.setForeground(new java.awt.Color(255, 51, 51));
        lblHinhMonAn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHinhMonAn.setText("Hình ảnh");
        lblHinhMonAn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        pnlCtrlFormMonAn.setBackground(new java.awt.Color(255, 255, 204));

        btnAddMonAn.setBackground(new java.awt.Color(51, 153, 255));
        btnAddMonAn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnAddMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-list-32.png"))); // NOI18N
        btnAddMonAn.setText("Thêm");
        btnAddMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddMonAnActionPerformed(evt);
            }
        });

        btnDeleteMonAn.setBackground(new java.awt.Color(51, 153, 255));
        btnDeleteMonAn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnDeleteMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete-32.png"))); // NOI18N
        btnDeleteMonAn.setText("Xóa");
        btnDeleteMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteMonAnActionPerformed(evt);
            }
        });

        btnUpdateMonAn.setBackground(new java.awt.Color(51, 153, 255));
        btnUpdateMonAn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnUpdateMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/available-updates-32.png"))); // NOI18N
        btnUpdateMonAn.setText("Chỉnh sửa");
        btnUpdateMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateMonAnActionPerformed(evt);
            }
        });

        btnResetMonAn.setBackground(new java.awt.Color(51, 153, 255));
        btnResetMonAn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnResetMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new-32.png"))); // NOI18N
        btnResetMonAn.setText("Làm mới");
        btnResetMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetMonAnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlCtrlFormMonAnLayout = new javax.swing.GroupLayout(pnlCtrlFormMonAn);
        pnlCtrlFormMonAn.setLayout(pnlCtrlFormMonAnLayout);
        pnlCtrlFormMonAnLayout.setHorizontalGroup(
            pnlCtrlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlFormMonAnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCtrlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnResetMonAn)
                    .addComponent(btnUpdateMonAn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addGroup(pnlCtrlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnAddMonAn)
                    .addComponent(btnDeleteMonAn))
                .addGap(21, 21, 21))
        );

        pnlCtrlFormMonAnLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAddMonAn, btnDeleteMonAn, btnResetMonAn, btnUpdateMonAn});

        pnlCtrlFormMonAnLayout.setVerticalGroup(
            pnlCtrlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlFormMonAnLayout.createSequentialGroup()
                .addGroup(pnlCtrlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnResetMonAn)
                    .addComponent(btnAddMonAn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlFormMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnUpdateMonAn)
                    .addComponent(btnDeleteMonAn)))
        );

        pnlCtrlDieuHuong1.setBackground(new java.awt.Color(255, 255, 204));

        btnFirstMonAn.setBackground(new java.awt.Color(51, 153, 255));
        btnFirstMonAn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnFirstMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/first-32.png"))); // NOI18N
        btnFirstMonAn.setText("Fisrt");
        btnFirstMonAn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFirstMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstMonAnActionPerformed(evt);
            }
        });

        btnPreMonAn.setBackground(new java.awt.Color(51, 153, 255));
        btnPreMonAn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnPreMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/previous-32.png"))); // NOI18N
        btnPreMonAn.setText("Previous");
        btnPreMonAn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPreMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreMonAnActionPerformed(evt);
            }
        });

        btnNextMonAn.setBackground(new java.awt.Color(51, 153, 255));
        btnNextMonAn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnNextMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/next-32.png"))); // NOI18N
        btnNextMonAn.setText("Next");
        btnNextMonAn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnNextMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextMonAnActionPerformed(evt);
            }
        });

        btnLastMonAn.setBackground(new java.awt.Color(51, 153, 255));
        btnLastMonAn.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnLastMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/last-32.png"))); // NOI18N
        btnLastMonAn.setText("Last");
        btnLastMonAn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLastMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastMonAnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlCtrlDieuHuong1Layout = new javax.swing.GroupLayout(pnlCtrlDieuHuong1);
        pnlCtrlDieuHuong1.setLayout(pnlCtrlDieuHuong1Layout);
        pnlCtrlDieuHuong1Layout.setHorizontalGroup(
            pnlCtrlDieuHuong1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlDieuHuong1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCtrlDieuHuong1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPreMonAn)
                    .addComponent(btnFirstMonAn))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlDieuHuong1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnLastMonAn)
                    .addComponent(btnNextMonAn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlCtrlDieuHuong1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnFirstMonAn, btnLastMonAn, btnNextMonAn, btnPreMonAn});

        pnlCtrlDieuHuong1Layout.setVerticalGroup(
            pnlCtrlDieuHuong1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlDieuHuong1Layout.createSequentialGroup()
                .addGroup(pnlCtrlDieuHuong1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPreMonAn)
                    .addComponent(btnNextMonAn))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlDieuHuong1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirstMonAn)
                    .addComponent(btnLastMonAn))
                .addGap(0, 12, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel2.setText("QUẢN LÝ MÓN ĂN");

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnFindMonAn.setText("Tìm Kiếm");
        btnFindMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindMonAnActionPerformed(evt);
            }
        });

        cboFindMonAn.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cboFindMonAn1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel1.setText("Loại món");

        jLabel4.setText("Món Ăn");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btnFindMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 163, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cboFindMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(cboFindMonAn1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(btnFindMonAn)
                .addGap(2, 2, 2)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboFindMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboFindMonAn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlMonAnLayout = new javax.swing.GroupLayout(pnlMonAn);
        pnlMonAn.setLayout(pnlMonAnLayout);
        pnlMonAnLayout.setHorizontalGroup(
            pnlMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMonAnLayout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(pnlMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlMonAnLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(443, 443, 443))
                    .addGroup(pnlMonAnLayout.createSequentialGroup()
                        .addGroup(pnlMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlFormMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlMonAnLayout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(pnlCtrlFormMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addGroup(pnlMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pnlCtrlDieuHuong1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHinhMonAn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(59, 59, 59))
        );
        pnlMonAnLayout.setVerticalGroup(
            pnlMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMonAnLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(pnlMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlFormMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlMonAnLayout.createSequentialGroup()
                        .addComponent(lblHinhMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(pnlMonAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCtrlDieuHuong1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCtrlFormMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        tabs.addTab("Món Ăn", pnlMonAn);

        pnlPhieuNhap.setBackground(new java.awt.Color(255, 255, 204));

        pnlFormPhieuNhap.setBackground(new java.awt.Color(255, 220, 126));
        pnlFormPhieuNhap.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Phiếu Nhập", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 3, 14), new java.awt.Color(51, 51, 255))); // NOI18N

        lblMaPhieuNhap.setText("Mã phiếu nhập");

        txtMaPhieuNhap.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, new java.awt.Color(255, 153, 0), null, null));

        lblNgayLapPhieu.setText("Ngày lập phiếu");

        txtNgayLapPhieu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, new java.awt.Color(255, 153, 0), null, null));

        lblNgayNhap.setText("Ngày nhập kho");

        txtNgayNhap.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, new java.awt.Color(255, 153, 0), null, null));

        jPanel4.setBackground(new java.awt.Color(255, 220, 126));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnUpdatePhieuNhap.setBackground(new java.awt.Color(51, 153, 255));
        btnUpdatePhieuNhap.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnUpdatePhieuNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/available-updates-32.png"))); // NOI18N
        btnUpdatePhieuNhap.setText("Chỉnh sửa");
        btnUpdatePhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdatePhieuNhapActionPerformed(evt);
            }
        });

        btnDeletePhieuNhap.setBackground(new java.awt.Color(51, 153, 255));
        btnDeletePhieuNhap.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnDeletePhieuNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete-32.png"))); // NOI18N
        btnDeletePhieuNhap.setText("Xóa");
        btnDeletePhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletePhieuNhapActionPerformed(evt);
            }
        });

        btnAddPhieuNhap.setBackground(new java.awt.Color(51, 153, 255));
        btnAddPhieuNhap.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnAddPhieuNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-list-32.png"))); // NOI18N
        btnAddPhieuNhap.setText("Thêm");
        btnAddPhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddPhieuNhapActionPerformed(evt);
            }
        });

        btnResetPhieuNhap.setBackground(new java.awt.Color(51, 153, 255));
        btnResetPhieuNhap.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnResetPhieuNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new-32.png"))); // NOI18N
        btnResetPhieuNhap.setText("Làm mới");
        btnResetPhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetPhieuNhapActionPerformed(evt);
            }
        });

        jPanel8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnFindPhieuNhap.setText("Tìm Kiếm");
        btnFindPhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindPhieuNhapActionPerformed(evt);
            }
        });

        cboFindPhieuNhap.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(btnFindPhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cboFindPhieuNhap, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFindPhieuNhap)
                    .addComponent(cboFindPhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnFirstPhieuNhap.setBackground(new java.awt.Color(51, 153, 255));
        btnFirstPhieuNhap.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnFirstPhieuNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/first-32.png"))); // NOI18N
        btnFirstPhieuNhap.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFirstPhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstPhieuNhapActionPerformed(evt);
            }
        });

        btnPrePhieuNhap.setBackground(new java.awt.Color(51, 153, 255));
        btnPrePhieuNhap.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnPrePhieuNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/previous-32.png"))); // NOI18N
        btnPrePhieuNhap.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPrePhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrePhieuNhapActionPerformed(evt);
            }
        });

        btnNextPhieuNhap.setBackground(new java.awt.Color(51, 153, 255));
        btnNextPhieuNhap.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnNextPhieuNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/next-32.png"))); // NOI18N
        btnNextPhieuNhap.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnNextPhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextPhieuNhapActionPerformed(evt);
            }
        });

        btnLastPhieuNhap.setBackground(new java.awt.Color(51, 153, 255));
        btnLastPhieuNhap.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnLastPhieuNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/last-32.png"))); // NOI18N
        btnLastPhieuNhap.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLastPhieuNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastPhieuNhapActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnResetPhieuNhap)
                            .addComponent(btnUpdatePhieuNhap))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDeletePhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAddPhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(btnFirstPhieuNhap)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPrePhieuNhap)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnNextPhieuNhap)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLastPhieuNhap)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAddPhieuNhap, btnDeletePhieuNhap, btnResetPhieuNhap, btnUpdatePhieuNhap});

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAddPhieuNhap)
                    .addComponent(btnResetPhieuNhap))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDeletePhieuNhap)
                    .addComponent(btnUpdatePhieuNhap))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirstPhieuNhap)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnPrePhieuNhap, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnNextPhieuNhap, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(btnLastPhieuNhap)))
        );

        lblNguoiNhap.setText("Người nhập");

        cboNguoiNhap.setBounds(new java.awt.Rectangle(0, 0, 1, 0));

        lblNhaCungCap.setText("Nhà cung cấp");

        cboNhaCungCap.setBounds(new java.awt.Rectangle(0, 0, 1, 0));

        javax.swing.GroupLayout pnlFormPhieuNhapLayout = new javax.swing.GroupLayout(pnlFormPhieuNhap);
        pnlFormPhieuNhap.setLayout(pnlFormPhieuNhapLayout);
        pnlFormPhieuNhapLayout.setHorizontalGroup(
            pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormPhieuNhapLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNgayNhap)
                    .addComponent(lblNgayLapPhieu)
                    .addGroup(pnlFormPhieuNhapLayout.createSequentialGroup()
                        .addGroup(pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblMaPhieuNhap)
                            .addComponent(lblNguoiNhap)
                            .addComponent(lblNhaCungCap))
                        .addGap(24, 24, 24)
                        .addGroup(pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNgayNhap, javax.swing.GroupLayout.DEFAULT_SIZE, 148, Short.MAX_VALUE)
                            .addComponent(txtNgayLapPhieu)
                            .addComponent(txtMaPhieuNhap)
                            .addComponent(cboNguoiNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboNhaCungCap, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlFormPhieuNhapLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtMaPhieuNhap, txtNgayLapPhieu, txtNgayNhap});

        pnlFormPhieuNhapLayout.setVerticalGroup(
            pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormPhieuNhapLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMaPhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMaPhieuNhap))
                .addGap(18, 18, 18)
                .addGroup(pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNgayLapPhieu)
                    .addComponent(txtNgayLapPhieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNgayNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNgayNhap))
                .addGap(18, 18, 18)
                .addGroup(pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNguoiNhap)
                    .addComponent(cboNguoiNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlFormPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNhaCungCap)
                    .addComponent(cboNhaCungCap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
            .addGroup(pnlFormPhieuNhapLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlFormPhieuNhapLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtMaPhieuNhap, txtNgayLapPhieu, txtNgayNhap});

        lblQLNhanVien.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        lblQLNhanVien.setText("QUẢN LÝ NHÂN VIÊN");

        pnlFormPhieuNhapCT.setBackground(new java.awt.Color(255, 220, 126));
        pnlFormPhieuNhapCT.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Phiếu Nhập Chi Tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 3, 14), new java.awt.Color(51, 51, 255))); // NOI18N

        lblMaPhieuNhap2.setText("Mã phiếu nhập");

        cboMaPhieuNhap.setBounds(new java.awt.Rectangle(0, 0, 1, 0));

        txtDonGiaNgLieu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, new java.awt.Color(255, 153, 0), null, null));

        lblTenNguyenLieu2.setText("Tên nguyên liệu");

        cboTenNguyenLieu.setBounds(new java.awt.Rectangle(0, 0, 1, 0));

        lblDonGiaNgLieu.setText("Đơn giá");

        lblDonViNgLieu.setText("Đơn vị");

        txtDonViNgLieu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, new java.awt.Color(255, 153, 0), null, null));

        lblSoLuongNgLieu.setText("Số lượng");

        txtSoLuongNgLieu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, new java.awt.Color(255, 153, 0), null, null));

        jPanel1.setBackground(new java.awt.Color(255, 220, 126));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnUpdatePhieuNhapCT.setBackground(new java.awt.Color(51, 153, 255));
        btnUpdatePhieuNhapCT.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnUpdatePhieuNhapCT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/available-updates-32.png"))); // NOI18N
        btnUpdatePhieuNhapCT.setText("Chỉnh sửa");
        btnUpdatePhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdatePhieuNhapCTActionPerformed(evt);
            }
        });

        btnDeletePhieuNhapCT.setBackground(new java.awt.Color(51, 153, 255));
        btnDeletePhieuNhapCT.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnDeletePhieuNhapCT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete-32.png"))); // NOI18N
        btnDeletePhieuNhapCT.setText("Xóa");
        btnDeletePhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletePhieuNhapCTActionPerformed(evt);
            }
        });

        btnAddPhieuNhapCT.setBackground(new java.awt.Color(51, 153, 255));
        btnAddPhieuNhapCT.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnAddPhieuNhapCT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-list-32.png"))); // NOI18N
        btnAddPhieuNhapCT.setText("Thêm");
        btnAddPhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddPhieuNhapCTActionPerformed(evt);
            }
        });

        btnResetPhieuNhapCT.setBackground(new java.awt.Color(51, 153, 255));
        btnResetPhieuNhapCT.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnResetPhieuNhapCT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new-32.png"))); // NOI18N
        btnResetPhieuNhapCT.setText("Làm mới");
        btnResetPhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetPhieuNhapCTActionPerformed(evt);
            }
        });

        jPanel6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnFindPhieuNhapCT.setText("Tìm Kiếm");
        btnFindPhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindPhieuNhapCTActionPerformed(evt);
            }
        });

        cboFindPhieuNhapCT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(btnFindPhieuNhapCT, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cboFindPhieuNhapCT, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFindPhieuNhapCT)
                    .addComponent(cboFindPhieuNhapCT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnLastPhieuNhapCT.setBackground(new java.awt.Color(51, 153, 255));
        btnLastPhieuNhapCT.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnLastPhieuNhapCT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/last-32.png"))); // NOI18N
        btnLastPhieuNhapCT.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLastPhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastPhieuNhapCTActionPerformed(evt);
            }
        });

        btnNextPhieuNhapCT.setBackground(new java.awt.Color(51, 153, 255));
        btnNextPhieuNhapCT.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnNextPhieuNhapCT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/next-32.png"))); // NOI18N
        btnNextPhieuNhapCT.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnNextPhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextPhieuNhapCTActionPerformed(evt);
            }
        });

        btnPrePhieuNhapCT.setBackground(new java.awt.Color(51, 153, 255));
        btnPrePhieuNhapCT.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnPrePhieuNhapCT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/previous-32.png"))); // NOI18N
        btnPrePhieuNhapCT.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPrePhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrePhieuNhapCTActionPerformed(evt);
            }
        });

        btnFirstPhieuNhapCT.setBackground(new java.awt.Color(51, 153, 255));
        btnFirstPhieuNhapCT.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnFirstPhieuNhapCT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/first-32.png"))); // NOI18N
        btnFirstPhieuNhapCT.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFirstPhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstPhieuNhapCTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnResetPhieuNhapCT)
                            .addComponent(btnUpdatePhieuNhapCT))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDeletePhieuNhapCT, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAddPhieuNhapCT)))
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFirstPhieuNhapCT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPrePhieuNhapCT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnNextPhieuNhapCT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLastPhieuNhapCT)
                .addGap(33, 33, 33))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAddPhieuNhapCT, btnDeletePhieuNhapCT, btnResetPhieuNhapCT, btnUpdatePhieuNhapCT});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnResetPhieuNhapCT)
                    .addComponent(btnAddPhieuNhapCT))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDeletePhieuNhapCT)
                    .addComponent(btnUpdatePhieuNhapCT))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirstPhieuNhapCT)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnPrePhieuNhapCT, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnNextPhieuNhapCT, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(btnLastPhieuNhapCT))
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlFormPhieuNhapCTLayout = new javax.swing.GroupLayout(pnlFormPhieuNhapCT);
        pnlFormPhieuNhapCT.setLayout(pnlFormPhieuNhapCTLayout);
        pnlFormPhieuNhapCTLayout.setHorizontalGroup(
            pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormPhieuNhapCTLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblDonViNgLieu, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblMaPhieuNhap2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSoLuongNgLieu, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTenNguyenLieu2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDonGiaNgLieu, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(18, 18, 18)
                .addGroup(pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(cboMaPhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cboTenNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtDonGiaNgLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtSoLuongNgLieu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDonViNgLieu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlFormPhieuNhapCTLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cboMaPhieuNhap, cboTenNguyenLieu, txtDonGiaNgLieu, txtDonViNgLieu, txtSoLuongNgLieu});

        pnlFormPhieuNhapCTLayout.setVerticalGroup(
            pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormPhieuNhapCTLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboMaPhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMaPhieuNhap2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboTenNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTenNguyenLieu2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDonGiaNgLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDonGiaNgLieu))
                .addGap(18, 18, 18)
                .addGroup(pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDonViNgLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDonViNgLieu))
                .addGap(18, 18, 18)
                .addGroup(pnlFormPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSoLuongNgLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSoLuongNgLieu))
                .addContainerGap(18, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlFormPhieuNhapCTLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlPhieuNhapLayout = new javax.swing.GroupLayout(pnlPhieuNhap);
        pnlPhieuNhap.setLayout(pnlPhieuNhapLayout);
        pnlPhieuNhapLayout.setHorizontalGroup(
            pnlPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPhieuNhapLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(lblQLNhanVien)
                .addContainerGap(488, Short.MAX_VALUE))
            .addGroup(pnlPhieuNhapLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnlFormPhieuNhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlFormPhieuNhapCT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlPhieuNhapLayout.setVerticalGroup(
            pnlPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlPhieuNhapLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblQLNhanVien)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlFormPhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlFormPhieuNhapCT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        tabs.addTab("Phiếu Nhập", pnlPhieuNhap);

        pnlNguyenLieu.setBackground(new java.awt.Color(255, 255, 204));

        pnlFormMonAn1.setBackground(new java.awt.Color(255, 220, 126));

        lblMaNgLieu.setText("Mã nguyên liệu");

        txtTenNgLieu.setForeground(new java.awt.Color(204, 204, 204));

        lblTenNguyenLieu.setText("Tên nguyên liệu");

        lblLoaiNguyenLieu.setText("Loại nguyên liệu");

        lblDonViNguyenLieu.setText("Đơn Vị");

        lblSoLuongNguyenLieu.setText("Số lượng");

        txtMaNgLieu.setForeground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout pnlFormMonAn1Layout = new javax.swing.GroupLayout(pnlFormMonAn1);
        pnlFormMonAn1.setLayout(pnlFormMonAn1Layout);
        pnlFormMonAn1Layout.setHorizontalGroup(
            pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormMonAn1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblMaNgLieu)
                    .addComponent(lblTenNguyenLieu)
                    .addComponent(lblLoaiNguyenLieu)
                    .addComponent(lblDonViNguyenLieu)
                    .addComponent(lblSoLuongNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtDonViNguyenLieu)
                    .addComponent(txtMaNgLieu)
                    .addComponent(txtTenNgLieu)
                    .addComponent(txtSoLuongNguyenLieu)
                    .addComponent(cboLoaiNguyenLieu, 0, 160, Short.MAX_VALUE))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        pnlFormMonAn1Layout.setVerticalGroup(
            pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormMonAn1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMaNgLieu)
                    .addComponent(txtMaNgLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTenNgLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTenNguyenLieu))
                .addGap(17, 17, 17)
                .addGroup(pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboLoaiNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLoaiNguyenLieu))
                .addGap(18, 18, 18)
                .addGroup(pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDonViNguyenLieu)
                    .addComponent(txtDonViNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSoLuongNguyenLieu)
                    .addComponent(txtSoLuongNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        lblHinhNguyenLieu.setBackground(new java.awt.Color(204, 204, 204));
        lblHinhNguyenLieu.setForeground(new java.awt.Color(255, 51, 51));
        lblHinhNguyenLieu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHinhNguyenLieu.setText("Hình ảnh");
        lblHinhNguyenLieu.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        pnlCtrlFormMonAn1.setBackground(new java.awt.Color(255, 255, 204));

        btnAddNguyenLieu.setBackground(new java.awt.Color(51, 153, 255));
        btnAddNguyenLieu.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnAddNguyenLieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-list-32.png"))); // NOI18N
        btnAddNguyenLieu.setText("Thêm");
        btnAddNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNguyenLieuActionPerformed(evt);
            }
        });

        btnDeleteNguyenLieu.setBackground(new java.awt.Color(51, 153, 255));
        btnDeleteNguyenLieu.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnDeleteNguyenLieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete-32.png"))); // NOI18N
        btnDeleteNguyenLieu.setText("Xóa");
        btnDeleteNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteNguyenLieuActionPerformed(evt);
            }
        });

        btnUpdateNguyenLieu.setBackground(new java.awt.Color(51, 153, 255));
        btnUpdateNguyenLieu.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnUpdateNguyenLieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/available-updates-32.png"))); // NOI18N
        btnUpdateNguyenLieu.setText("Chỉnh sửa");
        btnUpdateNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateNguyenLieuActionPerformed(evt);
            }
        });

        btnResetNguyenLieu.setBackground(new java.awt.Color(51, 153, 255));
        btnResetNguyenLieu.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnResetNguyenLieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new-32.png"))); // NOI18N
        btnResetNguyenLieu.setText("Làm mới");
        btnResetNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetNguyenLieuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlCtrlFormMonAn1Layout = new javax.swing.GroupLayout(pnlCtrlFormMonAn1);
        pnlCtrlFormMonAn1.setLayout(pnlCtrlFormMonAn1Layout);
        pnlCtrlFormMonAn1Layout.setHorizontalGroup(
            pnlCtrlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlFormMonAn1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCtrlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnResetNguyenLieu)
                    .addComponent(btnUpdateNguyenLieu))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnAddNguyenLieu)
                    .addComponent(btnDeleteNguyenLieu))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlCtrlFormMonAn1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAddNguyenLieu, btnDeleteNguyenLieu, btnResetNguyenLieu, btnUpdateNguyenLieu});

        pnlCtrlFormMonAn1Layout.setVerticalGroup(
            pnlCtrlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlFormMonAn1Layout.createSequentialGroup()
                .addGroup(pnlCtrlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnResetNguyenLieu)
                    .addComponent(btnAddNguyenLieu))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlFormMonAn1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnUpdateNguyenLieu)
                    .addComponent(btnDeleteNguyenLieu)))
        );

        pnlCtrlFormMonAn1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnAddNguyenLieu, btnDeleteNguyenLieu, btnResetNguyenLieu, btnUpdateNguyenLieu});

        pnlCtrlDieuHuong2.setBackground(new java.awt.Color(255, 255, 204));

        btnFirstNguyenLieu.setBackground(new java.awt.Color(51, 153, 255));
        btnFirstNguyenLieu.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnFirstNguyenLieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/first-32.png"))); // NOI18N
        btnFirstNguyenLieu.setText("Fisrt");
        btnFirstNguyenLieu.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFirstNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstNguyenLieuActionPerformed(evt);
            }
        });

        btnPreNguyenLieu.setBackground(new java.awt.Color(51, 153, 255));
        btnPreNguyenLieu.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnPreNguyenLieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/previous-32.png"))); // NOI18N
        btnPreNguyenLieu.setText("Previous");
        btnPreNguyenLieu.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPreNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreNguyenLieuActionPerformed(evt);
            }
        });

        btnNextNguyenLieu.setBackground(new java.awt.Color(51, 153, 255));
        btnNextNguyenLieu.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnNextNguyenLieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/next-32.png"))); // NOI18N
        btnNextNguyenLieu.setText("Next");
        btnNextNguyenLieu.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnNextNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextNguyenLieuActionPerformed(evt);
            }
        });

        btnLastNguyenLieu.setBackground(new java.awt.Color(51, 153, 255));
        btnLastNguyenLieu.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnLastNguyenLieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/last-32.png"))); // NOI18N
        btnLastNguyenLieu.setText("Last");
        btnLastNguyenLieu.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLastNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastNguyenLieuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlCtrlDieuHuong2Layout = new javax.swing.GroupLayout(pnlCtrlDieuHuong2);
        pnlCtrlDieuHuong2.setLayout(pnlCtrlDieuHuong2Layout);
        pnlCtrlDieuHuong2Layout.setHorizontalGroup(
            pnlCtrlDieuHuong2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCtrlDieuHuong2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlCtrlDieuHuong2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPreNguyenLieu)
                    .addComponent(btnFirstNguyenLieu))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlDieuHuong2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnLastNguyenLieu)
                    .addComponent(btnNextNguyenLieu))
                .addContainerGap())
        );

        pnlCtrlDieuHuong2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnFirstNguyenLieu, btnLastNguyenLieu, btnNextNguyenLieu, btnPreNguyenLieu});

        pnlCtrlDieuHuong2Layout.setVerticalGroup(
            pnlCtrlDieuHuong2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlDieuHuong2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCtrlDieuHuong2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPreNguyenLieu)
                    .addComponent(btnNextNguyenLieu))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlDieuHuong2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirstNguyenLieu)
                    .addComponent(btnLastNguyenLieu))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlCtrlDieuHuong2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnFirstNguyenLieu, btnLastNguyenLieu, btnNextNguyenLieu, btnPreNguyenLieu});

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel8.setText("QUẢN LÝ NGUYÊN LIỆU");

        jPanel7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnFindNguyenLieu.setText("Tìm Kiếm");
        btnFindNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindNguyenLieuActionPerformed(evt);
            }
        });

        cboFindNguyenLieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(btnFindNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cboFindNguyenLieu, 0, 163, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFindNguyenLieu)
                    .addComponent(cboFindNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlNguyenLieuLayout = new javax.swing.GroupLayout(pnlNguyenLieu);
        pnlNguyenLieu.setLayout(pnlNguyenLieuLayout);
        pnlNguyenLieuLayout.setHorizontalGroup(
            pnlNguyenLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNguyenLieuLayout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(pnlNguyenLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addGroup(pnlNguyenLieuLayout.createSequentialGroup()
                        .addGroup(pnlNguyenLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlNguyenLieuLayout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(pnlCtrlFormMonAn1, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(pnlFormMonAn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(pnlNguyenLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pnlCtrlDieuHuong2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblHinhNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        pnlNguyenLieuLayout.setVerticalGroup(
            pnlNguyenLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNguyenLieuLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(pnlNguyenLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlNguyenLieuLayout.createSequentialGroup()
                        .addComponent(lblHinhNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(pnlFormMonAn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlNguyenLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCtrlDieuHuong2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCtrlFormMonAn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        tabs.addTab("Nguyên Liệu", pnlNguyenLieu);

        pnlCongThuc.setBackground(new java.awt.Color(255, 255, 204));

        pnlFormCongThuc.setBackground(new java.awt.Color(255, 220, 126));

        jLabel53.setText("Mã Món");

        txtMaMonAuto.setBackground(java.awt.SystemColor.window);
        txtMaMonAuto.setForeground(new java.awt.Color(204, 204, 204));

        jLabel54.setText("Tên Món");

        txtDonViAuto.setBackground(java.awt.SystemColor.window);

        jLabel55.setText("Tên Nguyên Liệu");

        jLabel57.setText("Đơn Vị");

        cboTenMon.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboTenMonItemStateChanged(evt);
            }
        });

        jLabel58.setText("Số Lượng");

        cboNguyenLieu.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboNguyenLieuItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout pnlFormCongThucLayout = new javax.swing.GroupLayout(pnlFormCongThuc);
        pnlFormCongThuc.setLayout(pnlFormCongThucLayout);
        pnlFormCongThucLayout.setHorizontalGroup(
            pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormCongThucLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlFormCongThucLayout.createSequentialGroup()
                        .addComponent(jLabel55)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlFormCongThucLayout.createSequentialGroup()
                        .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel57)
                            .addComponent(jLabel58))
                        .addGap(51, 51, 51)
                        .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtSoLuong, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                            .addComponent(txtDonViAuto, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlFormCongThucLayout.createSequentialGroup()
                        .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel54)
                            .addComponent(jLabel53))
                        .addGap(57, 57, 57)
                        .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMaMonAuto, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboTenMon, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlFormCongThucLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cboNguyenLieu, cboTenMon, txtDonViAuto, txtMaMonAuto, txtSoLuong});

        pnlFormCongThucLayout.setVerticalGroup(
            pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlFormCongThucLayout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel53)
                    .addComponent(txtMaMonAuto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboTenMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel54))
                .addGap(18, 18, 18)
                .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel55))
                .addGap(18, 18, 18)
                .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel57)
                    .addComponent(txtDonViAuto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel58)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        lblHinhCongThuc.setBackground(new java.awt.Color(204, 204, 204));
        lblHinhCongThuc.setForeground(new java.awt.Color(255, 51, 51));
        lblHinhCongThuc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHinhCongThuc.setText("Hình ảnh");
        lblHinhCongThuc.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        pnlCtrlFormCongThuc.setBackground(new java.awt.Color(255, 255, 204));

        btnDeleteCongThuc.setBackground(new java.awt.Color(51, 153, 255));
        btnDeleteCongThuc.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnDeleteCongThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete-32.png"))); // NOI18N
        btnDeleteCongThuc.setText("Xóa");
        btnDeleteCongThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteCongThucActionPerformed(evt);
            }
        });

        btnAddCongThuc.setBackground(new java.awt.Color(51, 153, 255));
        btnAddCongThuc.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnAddCongThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-list-32.png"))); // NOI18N
        btnAddCongThuc.setText("Thêm");
        btnAddCongThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddCongThucActionPerformed(evt);
            }
        });

        btnResetCongThuc.setBackground(new java.awt.Color(51, 153, 255));
        btnResetCongThuc.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnResetCongThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new-32.png"))); // NOI18N
        btnResetCongThuc.setText("Làm mới");
        btnResetCongThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetCongThucActionPerformed(evt);
            }
        });

        btnUpdateCongThuc.setBackground(new java.awt.Color(51, 153, 255));
        btnUpdateCongThuc.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnUpdateCongThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/available-updates-32.png"))); // NOI18N
        btnUpdateCongThuc.setText("Chỉnh sửa");
        btnUpdateCongThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateCongThucActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlCtrlFormCongThucLayout = new javax.swing.GroupLayout(pnlCtrlFormCongThuc);
        pnlCtrlFormCongThuc.setLayout(pnlCtrlFormCongThucLayout);
        pnlCtrlFormCongThucLayout.setHorizontalGroup(
            pnlCtrlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlFormCongThucLayout.createSequentialGroup()
                .addGroup(pnlCtrlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnResetCongThuc)
                    .addComponent(btnUpdateCongThuc, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlCtrlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnAddCongThuc, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDeleteCongThuc, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pnlCtrlFormCongThucLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAddCongThuc, btnDeleteCongThuc, btnResetCongThuc, btnUpdateCongThuc});

        pnlCtrlFormCongThucLayout.setVerticalGroup(
            pnlCtrlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlFormCongThucLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCtrlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnResetCongThuc)
                    .addComponent(btnAddCongThuc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlFormCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnUpdateCongThuc, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDeleteCongThuc))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlCtrlDieuHuong.setBackground(new java.awt.Color(255, 255, 204));

        btnFirstCongThuc.setBackground(new java.awt.Color(51, 153, 255));
        btnFirstCongThuc.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnFirstCongThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/first-32.png"))); // NOI18N
        btnFirstCongThuc.setText("Fisrt");
        btnFirstCongThuc.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFirstCongThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstCongThucActionPerformed(evt);
            }
        });

        btnPreCongThuc.setBackground(new java.awt.Color(51, 153, 255));
        btnPreCongThuc.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnPreCongThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/previous-32.png"))); // NOI18N
        btnPreCongThuc.setText("Previous");
        btnPreCongThuc.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPreCongThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreCongThucActionPerformed(evt);
            }
        });

        btnNextCongThuc.setBackground(new java.awt.Color(51, 153, 255));
        btnNextCongThuc.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnNextCongThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/next-32.png"))); // NOI18N
        btnNextCongThuc.setText("Next");
        btnNextCongThuc.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnNextCongThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextCongThucActionPerformed(evt);
            }
        });

        btnLastCongThuc.setBackground(new java.awt.Color(51, 153, 255));
        btnLastCongThuc.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnLastCongThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/last-32.png"))); // NOI18N
        btnLastCongThuc.setText("Last");
        btnLastCongThuc.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLastCongThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastCongThucActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlCtrlDieuHuongLayout = new javax.swing.GroupLayout(pnlCtrlDieuHuong);
        pnlCtrlDieuHuong.setLayout(pnlCtrlDieuHuongLayout);
        pnlCtrlDieuHuongLayout.setHorizontalGroup(
            pnlCtrlDieuHuongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCtrlDieuHuongLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlCtrlDieuHuongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPreCongThuc)
                    .addComponent(btnFirstCongThuc))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlDieuHuongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnLastCongThuc)
                    .addComponent(btnNextCongThuc))
                .addContainerGap())
        );

        pnlCtrlDieuHuongLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnFirstCongThuc, btnLastCongThuc, btnNextCongThuc, btnPreCongThuc});

        pnlCtrlDieuHuongLayout.setVerticalGroup(
            pnlCtrlDieuHuongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCtrlDieuHuongLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCtrlDieuHuongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPreCongThuc)
                    .addComponent(btnNextCongThuc))
                .addGap(18, 18, 18)
                .addGroup(pnlCtrlDieuHuongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirstCongThuc)
                    .addComponent(btnLastCongThuc))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlCtrlDieuHuongLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnFirstCongThuc, btnLastCongThuc, btnNextCongThuc, btnPreCongThuc});

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel3.setText("QUẢN LÝ CÔNG THỨC");

        javax.swing.GroupLayout pnlCongThucLayout = new javax.swing.GroupLayout(pnlCongThuc);
        pnlCongThuc.setLayout(pnlCongThucLayout);
        pnlCongThucLayout.setHorizontalGroup(
            pnlCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCongThucLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(pnlCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCongThucLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(466, 466, 466))
                    .addGroup(pnlCongThucLayout.createSequentialGroup()
                        .addGroup(pnlCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnlCtrlFormCongThuc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pnlFormCongThuc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(pnlCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pnlCtrlDieuHuong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHinhCongThuc, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(60, 60, 60))))
        );
        pnlCongThucLayout.setVerticalGroup(
            pnlCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCongThucLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(pnlCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblHinhCongThuc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlFormCongThuc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(pnlCongThucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pnlCtrlFormCongThuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCtrlDieuHuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(62, Short.MAX_VALUE))
        );

        tabs.addTab("Công Thức", pnlCongThuc);

        mnbarThemMoi.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        mnbarThemMoi.setMaximumSize(new java.awt.Dimension(710, 29));
        mnbarThemMoi.setMinimumSize(new java.awt.Dimension(710, 29));
        mnbarThemMoi.setPreferredSize(new java.awt.Dimension(710, 29));

        mnDanhmuc.setText("Danh Mục");
        mnbarThemMoi.add(mnDanhmuc);

        mnThemmoi.setBackground(new java.awt.Color(0, 102, 255));
        mnThemmoi.setBorder(null);
        mnThemmoi.setForeground(new java.awt.Color(255, 255, 255));
        mnThemmoi.setText("Thêm Mới");
        mnbarThemMoi.add(mnThemmoi);

        mnThongke.setText("Thống Kê");
        mnThongke.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        mnbarThemMoi.add(mnThongke);

        mnExit.setText("Thoát");
        mnbarThemMoi.add(mnExit);

        setJMenuBar(mnbarThemMoi);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addComponent(tabs, javax.swing.GroupLayout.PREFERRED_SIZE, 751, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(tabs, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFindMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindMonAnActionPerformed
        // TODO add your handling code here:
        this.setFormMonAn((String) cboFindMonAn.getSelectedItem());
    }//GEN-LAST:event_btnFindMonAnActionPerformed

    private void btnLastMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastMonAnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLastMonAnActionPerformed

    private void btnNextMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextMonAnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNextMonAnActionPerformed

    private void btnPreMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreMonAnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPreMonAnActionPerformed

    private void btnFirstMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstMonAnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFirstMonAnActionPerformed

    private void btnResetMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetMonAnActionPerformed
        // TODO add your handling code here:
        this.resetFormMonAn();
    }//GEN-LAST:event_btnResetMonAnActionPerformed

    private void btnUpdateMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateMonAnActionPerformed
        // TODO add your handling code here:
        MonAn nv = this.getFormMonAn();
        QLMonAn.update(nv);
        QLMonAn.fillToFoodCbo(cboFindMonAn);
    }//GEN-LAST:event_btnUpdateMonAnActionPerformed

    private void btnDeleteMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteMonAnActionPerformed
        // TODO add your handling code here:
        if (QLMonAn.detele(txtMaMon.getText())) {
            this.resetFormMonAn();
            QLMonAn.fillToFoodCbo(cboFindMonAn);
        }
    }//GEN-LAST:event_btnDeleteMonAnActionPerformed

    private void btnAddMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddMonAnActionPerformed
        // TODO add your handling code here:
        MonAn mon = this.getFormMonAn();
        QLMonAn.insert(mon);
        QLMonAn.fillToFoodCbo(cboFindMonAn);
//        QLMonAn.fillToFoodCbo(cboTenMon);
        DefaultComboBoxModel model = (DefaultComboBoxModel) cboTenMon.getModel();
        model.addElement(mon.getTenMon());
    }//GEN-LAST:event_btnAddMonAnActionPerformed

    private void btnLastNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastNhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLastNhanVienActionPerformed

    private void btnFirstNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstNhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFirstNhanVienActionPerformed

    private void btnNextNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextNhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNextNhanVienActionPerformed

    private void btnPreNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreNhanVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPreNhanVienActionPerformed

    private void btnFindNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindNhanVienActionPerformed
        // TODO add your handling code here:
        this.setFormNhanVien(cboFindNhanVien.getSelectedItem().toString());
    }//GEN-LAST:event_btnFindNhanVienActionPerformed

    private void btnDeleteNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteNhanVienActionPerformed
        // TODO add your handling code here:
        if (QLNhanVien.detele(txtMaNV.getText())) {
            this.resetFormNhanVien();
            QLNhanVien.fillComboBoxNhanVien(cboFindNhanVien);
        }
    }//GEN-LAST:event_btnDeleteNhanVienActionPerformed

    private void btnUpdateNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateNhanVienActionPerformed
        // TODO add your handling code here:
        NhanVien nv = this.getFormNhanVien();
        if (nv != null) {
            QLNhanVien.update(nv);
            QLNhanVien.fillComboBoxNhanVien(cboFindNhanVien);
        }
    }//GEN-LAST:event_btnUpdateNhanVienActionPerformed

    private void btnAddNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNhanVienActionPerformed
        // TODO add your handling code here:
        NhanVien nv = this.getFormNhanVien();
        if (nv != null) {
            QLNhanVien.insert(nv);
            QLNhanVien.fillComboBoxNhanVien(cboFindNhanVien);
            QLNhanVien.fillComboBoxNhanVien(cboNguoiNhap);
        }
    }//GEN-LAST:event_btnAddNhanVienActionPerformed

    private void btnResetNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetNhanVienActionPerformed
        // TODO add your handling code here:
        this.resetFormNhanVien();
    }//GEN-LAST:event_btnResetNhanVienActionPerformed

    private void btnFindPhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindPhieuNhapActionPerformed
        // TODO add your handling code here:
        this.setFormPhieuNhap(cboFindPhieuNhap.getSelectedItem().toString());
    }//GEN-LAST:event_btnFindPhieuNhapActionPerformed

    private void btnResetPhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetPhieuNhapActionPerformed
        // TODO add your handling code here:
        this.resetFormPhieuNhap();
    }//GEN-LAST:event_btnResetPhieuNhapActionPerformed

    private void btnUpdatePhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdatePhieuNhapActionPerformed
        // TODO add your handling code here:
        PhieuNhap pn = this.getFormPhieuNhap();
        QLPhieuNhap.update(pn);
        QLPhieuNhap.fillComboBoxPhieuNhap(cboFindPhieuNhap);
    }//GEN-LAST:event_btnUpdatePhieuNhapActionPerformed

    private void btnAddPhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddPhieuNhapActionPerformed
        // TODO add your handling code here:
        PhieuNhap pn = this.getFormPhieuNhap();
        QLPhieuNhap.insert(pn);
        QLPhieuNhap.fillComboBoxPhieuNhap(cboFindPhieuNhap);
        QLPhieuNhap.fillComboBoxPhieuNhap(cboMaPhieuNhap);
    }//GEN-LAST:event_btnAddPhieuNhapActionPerformed

    private void btnDeletePhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletePhieuNhapActionPerformed
        // TODO add your handling code here:
        if (QLNguyenLieu.detele(txtMaNgLieu.getText())) {
            this.resetFormNguyenLieu();
            QLNguyenLieu.fillToIngredientCbo(cboFindNguyenLieu);
        }
    }//GEN-LAST:event_btnDeletePhieuNhapActionPerformed

    private void btnFirstPhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstPhieuNhapActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFirstPhieuNhapActionPerformed

    private void btnPrePhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrePhieuNhapActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPrePhieuNhapActionPerformed

    private void btnNextPhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextPhieuNhapActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNextPhieuNhapActionPerformed

    private void btnLastPhieuNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastPhieuNhapActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLastPhieuNhapActionPerformed

    private void btnFindPhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindPhieuNhapCTActionPerformed
        // TODO add your handling code here:
        this.setFormPhieuNhapCT(cboFindPhieuNhapCT.getSelectedItem().toString());
    }//GEN-LAST:event_btnFindPhieuNhapCTActionPerformed

    private void btnResetPhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetPhieuNhapCTActionPerformed
        // TODO add your handling code here:
        this.resetFormPhieuNhapCT();
    }//GEN-LAST:event_btnResetPhieuNhapCTActionPerformed

    private void btnAddPhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddPhieuNhapCTActionPerformed
        // TODO add your handling code here:
        PhieuNhapCT pn = this.getFormPhieuNhapCT();
        QLPhieuNhapCT.insert(pn);
        QLPhieuNhapCT.fillComboBoxPhieuNhapCT(cboFindPhieuNhapCT);
    }//GEN-LAST:event_btnAddPhieuNhapCTActionPerformed

    private void btnUpdatePhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdatePhieuNhapCTActionPerformed
        // TODO add your handling code here:
        PhieuNhapCT pn = this.getFormPhieuNhapCT();
        QLPhieuNhapCT.update(pn);
        QLPhieuNhapCT.fillComboBoxPhieuNhapCT(cboFindPhieuNhapCT);
    }//GEN-LAST:event_btnUpdatePhieuNhapCTActionPerformed

    private void btnDeletePhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletePhieuNhapCTActionPerformed
        // TODO add your handling code here:
        String[] ids = {cboMaPhieuNhap.getSelectedItem().toString(), cboTenNguyenLieu.getSelectedItem().toString()};
        String maPhieuNhapCT = String.valueOf(daoPNCT.selectByIds(ids).getMaPhieuNhapCT());
        if (QLPhieuNhapCT.detele(maPhieuNhapCT)) {
            this.resetFormPhieuNhapCT();
            QLPhieuNhapCT.fillComboBoxPhieuNhapCT(cboFindPhieuNhapCT);
        }
    }//GEN-LAST:event_btnDeletePhieuNhapCTActionPerformed

    private void btnFirstPhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstPhieuNhapCTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFirstPhieuNhapCTActionPerformed

    private void btnPrePhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrePhieuNhapCTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPrePhieuNhapCTActionPerformed

    private void btnNextPhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextPhieuNhapCTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNextPhieuNhapCTActionPerformed

    private void btnLastPhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastPhieuNhapCTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLastPhieuNhapCTActionPerformed

    private void btnResetNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetNguyenLieuActionPerformed
        // TODO add your handling code here:
        this.resetFormNguyenLieu();
    }//GEN-LAST:event_btnResetNguyenLieuActionPerformed

    private void btnAddNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNguyenLieuActionPerformed
        // TODO add your handling code here:
        NguyenLieu nl = this.getFormNguyenLieu();
        QLNguyenLieu.insert(nl);
        QLNguyenLieu.fillToIngredientCbo(cboTenNguyenLieu);
        QLNguyenLieu.fillToIngredientCbo(cboFindNguyenLieu);
        QLNguyenLieu.fillToIngredientCbo(cboNguyenLieu);
    }//GEN-LAST:event_btnAddNguyenLieuActionPerformed

    private void btnUpdateNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateNguyenLieuActionPerformed
        // TODO add your handling code here:
        NguyenLieu nl = this.getFormNguyenLieu();
        QLNguyenLieu.insert(nl);
        QLNguyenLieu.fillToIngredientCbo(cboFindNguyenLieu);
    }//GEN-LAST:event_btnUpdateNguyenLieuActionPerformed

    private void btnDeleteNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteNguyenLieuActionPerformed
        // TODO add your handling code here:
        if (QLNguyenLieu.detele(txtMaNgLieu.getText())) {
            this.resetFormNguyenLieu();
            QLNguyenLieu.fillToIngredientCbo(cboFindNguyenLieu);
        }
    }//GEN-LAST:event_btnDeleteNguyenLieuActionPerformed

    private void btnPreNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreNguyenLieuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPreNguyenLieuActionPerformed

    private void btnNextNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextNguyenLieuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNextNguyenLieuActionPerformed

    private void btnFirstNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstNguyenLieuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFirstNguyenLieuActionPerformed

    private void btnLastNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastNguyenLieuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLastNguyenLieuActionPerformed

    private void btnFindNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindNguyenLieuActionPerformed
        // TODO add your handling code here:
        this.setFormNguyenLieu(cboFindNguyenLieu.getSelectedItem().toString());
    }//GEN-LAST:event_btnFindNguyenLieuActionPerformed

    private void btnResetCongThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetCongThucActionPerformed
        // TODO add your handling code here:
        this.resetFormCongThuc();
    }//GEN-LAST:event_btnResetCongThucActionPerformed

    private void btnAddCongThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddCongThucActionPerformed
        // TODO add your handling code here:
        CongThuc ct = this.getFormCongThuc();
        QLCongThuc.insert(ct);
    }//GEN-LAST:event_btnAddCongThucActionPerformed

    private void btnUpdateCongThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateCongThucActionPerformed
        // TODO add your handling code here:
        CongThuc ct = this.getFormCongThuc();
        QLCongThuc.update(ct);
    }//GEN-LAST:event_btnUpdateCongThucActionPerformed

    private void btnDeleteCongThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteCongThucActionPerformed
        // TODO add your handling code here:
        String[] ids = {cboTenMon.getSelectedItem().toString(), cboNguyenLieu.getSelectedItem().toString()};
        if (QLCongThuc.detele(ids)) {
            this.resetFormCongThuc();
        }
    }//GEN-LAST:event_btnDeleteCongThucActionPerformed

    private void btnPreCongThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreCongThucActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPreCongThucActionPerformed

    private void btnNextCongThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextCongThucActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNextCongThucActionPerformed

    private void btnFirstCongThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstCongThucActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFirstCongThucActionPerformed

    private void btnLastCongThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastCongThucActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLastCongThucActionPerformed

    private void cboTenMonItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboTenMonItemStateChanged
        // TODO add your handling code here:
        String tenMon = String.valueOf(cboTenMon.getSelectedItem());
        txtMaMonAuto.setEnabled(false);
        if (!tenMon.equals("Chưa chọn")) {
            String maMon = daoMA.selectByName(tenMon).getMaMon();
            txtMaMonAuto.setText(maMon);
        }
    }//GEN-LAST:event_cboTenMonItemStateChanged

    private void cboNguyenLieuItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboNguyenLieuItemStateChanged
        // TODO add your handling code here:
        String nguyenLieu = cboNguyenLieu.getSelectedItem().toString();
        txtDonViAuto.setEnabled(false);
        if (!nguyenLieu.equals("Chưa chọn")) {
            String donVi = daoNL.selectByName(nguyenLieu).getDonVi();
            txtDonViAuto.setText(donVi);
        }
    }//GEN-LAST:event_cboNguyenLieuItemStateChanged

    private void lblHinhNhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHinhNhanVienMouseClicked
        // TODO add your handling code here:
        this.chonAnh(lblHinhNhanVien);
    }//GEN-LAST:event_lblHinhNhanVienMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ThemMoi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddCongThuc;
    private javax.swing.JButton btnAddMonAn;
    private javax.swing.JButton btnAddNguyenLieu;
    private javax.swing.JButton btnAddNhanVien;
    private javax.swing.JButton btnAddPhieuNhap;
    private javax.swing.JButton btnAddPhieuNhapCT;
    private javax.swing.JButton btnDeleteCongThuc;
    private javax.swing.JButton btnDeleteMonAn;
    private javax.swing.JButton btnDeleteNguyenLieu;
    private javax.swing.JButton btnDeleteNhanVien;
    private javax.swing.JButton btnDeletePhieuNhap;
    private javax.swing.JButton btnDeletePhieuNhapCT;
    private javax.swing.JButton btnFindMonAn;
    private javax.swing.JButton btnFindNguyenLieu;
    private javax.swing.JButton btnFindNhanVien;
    private javax.swing.JButton btnFindPhieuNhap;
    private javax.swing.JButton btnFindPhieuNhapCT;
    private javax.swing.JButton btnFirstCongThuc;
    private javax.swing.JButton btnFirstMonAn;
    private javax.swing.JButton btnFirstNguyenLieu;
    private javax.swing.JButton btnFirstNhanVien;
    private javax.swing.JButton btnFirstPhieuNhap;
    private javax.swing.JButton btnFirstPhieuNhapCT;
    private javax.swing.ButtonGroup btnGroupGender;
    private javax.swing.JButton btnLastCongThuc;
    private javax.swing.JButton btnLastMonAn;
    private javax.swing.JButton btnLastNguyenLieu;
    private javax.swing.JButton btnLastNhanVien;
    private javax.swing.JButton btnLastPhieuNhap;
    private javax.swing.JButton btnLastPhieuNhapCT;
    private javax.swing.JButton btnNextCongThuc;
    private javax.swing.JButton btnNextMonAn;
    private javax.swing.JButton btnNextNguyenLieu;
    private javax.swing.JButton btnNextNhanVien;
    private javax.swing.JButton btnNextPhieuNhap;
    private javax.swing.JButton btnNextPhieuNhapCT;
    private javax.swing.JButton btnPreCongThuc;
    private javax.swing.JButton btnPreMonAn;
    private javax.swing.JButton btnPreNguyenLieu;
    private javax.swing.JButton btnPreNhanVien;
    private javax.swing.JButton btnPrePhieuNhap;
    private javax.swing.JButton btnPrePhieuNhapCT;
    private javax.swing.JButton btnResetCongThuc;
    private javax.swing.JButton btnResetMonAn;
    private javax.swing.JButton btnResetNguyenLieu;
    private javax.swing.JButton btnResetNhanVien;
    private javax.swing.JButton btnResetPhieuNhap;
    private javax.swing.JButton btnResetPhieuNhapCT;
    private javax.swing.JButton btnUpdateCongThuc;
    private javax.swing.JButton btnUpdateMonAn;
    private javax.swing.JButton btnUpdateNguyenLieu;
    private javax.swing.JButton btnUpdateNhanVien;
    private javax.swing.JButton btnUpdatePhieuNhap;
    private javax.swing.JButton btnUpdatePhieuNhapCT;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cboCaTruc;
    private javax.swing.JComboBox<String> cboChucVu;
    private javax.swing.JComboBox<String> cboFindMonAn;
    private javax.swing.JComboBox<String> cboFindMonAn1;
    private javax.swing.JComboBox<String> cboFindNguyenLieu;
    private javax.swing.JComboBox<String> cboFindNhanVien;
    private javax.swing.JComboBox<String> cboFindPhieuNhap;
    private javax.swing.JComboBox<String> cboFindPhieuNhapCT;
    private javax.swing.JComboBox<String> cboLoaiMon;
    private javax.swing.JComboBox<String> cboLoaiNguyenLieu;
    private javax.swing.JComboBox<String> cboMaPhieuNhap;
    private javax.swing.JComboBox<String> cboNguoiNhap;
    private javax.swing.JComboBox<String> cboNguyenLieu;
    private javax.swing.JComboBox<String> cboNhaCungCap;
    private javax.swing.JComboBox<String> cboTenMon;
    private javax.swing.JComboBox<String> cboTenNguyenLieu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JLabel lblCaTruc;
    private javax.swing.JLabel lblChucVu;
    private javax.swing.JLabel lblDiaChi;
    private javax.swing.JLabel lblDonGia;
    private javax.swing.JLabel lblDonGiaNgLieu;
    private javax.swing.JLabel lblDonVi;
    private javax.swing.JLabel lblDonViNgLieu;
    private javax.swing.JLabel lblDonViNguyenLieu;
    private javax.swing.JLabel lblHinhCongThuc;
    private javax.swing.JLabel lblHinhMonAn;
    private javax.swing.JLabel lblHinhNguyenLieu;
    private javax.swing.JLabel lblHinhNhanVien;
    private javax.swing.JLabel lblHoTen;
    private javax.swing.JLabel lblLoaiMon;
    private javax.swing.JLabel lblLoaiNguyenLieu;
    private javax.swing.JLabel lblLuong;
    private javax.swing.JLabel lblMaMon;
    private javax.swing.JLabel lblMaNV;
    private javax.swing.JLabel lblMaNgLieu;
    private javax.swing.JLabel lblMaPhieuNhap;
    private javax.swing.JLabel lblMaPhieuNhap2;
    private javax.swing.JLabel lblNgayLapPhieu;
    private javax.swing.JLabel lblNgayNhap;
    private javax.swing.JLabel lblNguoiNhap;
    private javax.swing.JLabel lblNhaCungCap;
    private javax.swing.JLabel lblPass;
    private javax.swing.JLabel lblQLNhanVien;
    private javax.swing.JLabel lblSoDT;
    private javax.swing.JLabel lblSoLuongNgLieu;
    private javax.swing.JLabel lblSoLuongNguyenLieu;
    private javax.swing.JLabel lblTenMon;
    private javax.swing.JLabel lblTenNguyenLieu;
    private javax.swing.JLabel lblTenNguyenLieu2;
    private javax.swing.JLabel lblTitleNV;
    private javax.swing.JMenu mnDanhmuc;
    private javax.swing.JMenu mnExit;
    private javax.swing.JMenu mnThemmoi;
    private javax.swing.JMenu mnThongke;
    private javax.swing.JMenuBar mnbarThemMoi;
    private javax.swing.JPanel pnlCongThuc;
    private javax.swing.JPanel pnlCtrlDieuHuong;
    private javax.swing.JPanel pnlCtrlDieuHuong1;
    private javax.swing.JPanel pnlCtrlDieuHuong2;
    private javax.swing.JPanel pnlCtrlFormCongThuc;
    private javax.swing.JPanel pnlCtrlFormMonAn;
    private javax.swing.JPanel pnlCtrlFormMonAn1;
    private javax.swing.JPanel pnlCtrlFormNhanVien;
    private javax.swing.JPanel pnlFormCongThuc;
    private javax.swing.JPanel pnlFormMonAn;
    private javax.swing.JPanel pnlFormMonAn1;
    private javax.swing.JPanel pnlFormNhanVien;
    private javax.swing.JPanel pnlFormPhieuNhap;
    private javax.swing.JPanel pnlFormPhieuNhapCT;
    private javax.swing.JPanel pnlMonAn;
    private javax.swing.JPanel pnlNguyenLieu;
    private javax.swing.JPanel pnlNhanvien;
    private javax.swing.JPanel pnlPhieuNhap;
    private javax.swing.JRadioButton rdoNam;
    private javax.swing.JRadioButton rdoNu;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtDonGia;
    private javax.swing.JTextField txtDonGiaNgLieu;
    private javax.swing.JTextField txtDonVi;
    private javax.swing.JTextField txtDonViAuto;
    private javax.swing.JTextField txtDonViNgLieu;
    private javax.swing.JTextField txtDonViNguyenLieu;
    private javax.swing.JTextField txtHoTen;
    private javax.swing.JTextField txtLuong;
    private javax.swing.JTextField txtMaMon;
    private javax.swing.JTextField txtMaMonAuto;
    private javax.swing.JTextField txtMaNV;
    private javax.swing.JTextField txtMaNgLieu;
    private javax.swing.JTextField txtMaPhieuNhap;
    private javax.swing.JTextField txtNgayLapPhieu;
    private javax.swing.JTextField txtNgayNhap;
    private javax.swing.JTextField txtPass;
    private javax.swing.JTextField txtSoDT;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtSoLuongNgLieu;
    private javax.swing.JTextField txtSoLuongNguyenLieu;
    private javax.swing.JTextField txtTenMon;
    private javax.swing.JTextField txtTenNgLieu;
    // End of variables declaration//GEN-END:variables

    void fillComboBox() {
        /*
            Form NhanVien
         */
        QLNhanVien.fillComboBoxChucVu(cboChucVu);
        QLNhanVien.fillComboBoxCatruc(cboCaTruc);
        QLNhanVien.fillComboBoxNhanVien(cboFindNhanVien);

        /*
            Form MonAn
         */
        QLMonAn.fillToTypesOfFoodCbo(cboLoaiMon);
        QLMonAn.fillToFoodCbo(cboFindMonAn);

        /*
            Form PhieuNhap
         */
        QLNhanVien.fillComboBoxNhanVien(cboNguoiNhap);
        QLPhieuNhap.fillComboBoxNhaCungCap(cboNhaCungCap);
        QLPhieuNhap.fillComboBoxPhieuNhap(cboFindPhieuNhap);

        /*
            Form PhieuNhapCT
         */
        QLPhieuNhap.fillComboBoxPhieuNhap(cboMaPhieuNhap);
        QLNguyenLieu.fillToIngredientCbo(cboTenNguyenLieu);
        QLPhieuNhapCT.fillComboBoxPhieuNhapCT(cboFindPhieuNhapCT);

        /*
            Form NguyenLieu
         */
        QLNguyenLieu.fillToTypeOfIngredientCbo(cboLoaiNguyenLieu);
        QLNguyenLieu.fillToIngredientCbo(cboFindNguyenLieu);
        /*
            Form CongThuc
         */
        QLMonAn.fillToFoodCbo(cboTenMon);
        QLNguyenLieu.fillToIngredientCbo(cboNguyenLieu);

    }

    NhanVienDAO daoNV = new NhanVienDAO();
    ChucVuDAO daoCV = new ChucVuDAO();

    void resetFormNhanVien() {
        txtMaNV.setText("");
        txtHoTen.setText("");
        rdoNam.setSelected(true);
        txtSoDT.setText("");
        txtDiaChi.setText("");
        cboChucVu.setSelectedIndex(0);
        cboCaTruc.setSelectedIndex(0);
        txtLuong.setText("");
        txtPass.setText("");
    }

    void setFormNhanVien(String name) {
        NhanVien nv = daoNV.selectByName(name);
        if (nv != null) {
            txtMaNV.setText(nv.getMaNV());
            txtHoTen.setText(nv.getHoTenNV());
            rdoNam.setSelected(nv.getGioiTinh().equals("Nam") ? true : false);
            txtSoDT.setText(nv.getSoDT());
            txtDiaChi.setText(nv.getDiaChi());
            String chucVu = daoCV.selectById(nv.getMaCV()).getChucVu();
            cboChucVu.setSelectedItem(chucVu);
            cboCaTruc.setSelectedItem(nv.getMaCaTruc());
            txtLuong.setText(String.valueOf(nv.getLuong()));
            txtPass.setText(nv.getMatKhau());
        } else {
            MsgBox.alert(this, "Không tìm thấy thông tin nhân viên!");
        }
    }

    NhanVien getFormNhanVien() {
        NhanVien entity = new NhanVien();
        entity.setMaNV(txtMaNV.getText().trim());
        entity.setHoTenNV(txtHoTen.getText().trim());
        entity.setGioiTinh(rdoNam.isSelected() ? "Nam" : "Nữ");
        entity.setSoDT(txtSoDT.getText().trim());
        entity.setDiaChi(txtDiaChi.getText().trim());
        String maCV = String.valueOf(daoCV.selectByName((String) cboChucVu.getSelectedItem()).getMaCV());
        entity.setMaCV(maCV);
        entity.setMaCaTruc((int) cboCaTruc.getSelectedItem());
        entity.setLuong(Float.valueOf(txtLuong.getText().trim()));
        entity.setMatKhau(txtPass.getText().trim());
        return entity;
    }

    MonAnDAO daoMA = new MonAnDAO();
    LoaiMonDAO daoLM = new LoaiMonDAO();

    void resetFormMonAn() {
        txtMaMon.setText("");
        txtTenMon.setText("");
        cboLoaiMon.setSelectedIndex(0);
        txtDonVi.setText("");
        txtDonGia.setText("");
    }

    void setFormMonAn(String name) {
        MonAn mon = daoMA.selectByName(name);
        if (mon != null) {
            txtMaMon.setText(mon.getMaMon());
            txtTenMon.setText(mon.getTenMon());
            String loaiMon = daoLM.selectById(mon.getMaLoaiMon()).getTenLoaiMon();
            cboLoaiMon.setSelectedItem(loaiMon);
            txtDonVi.setText(mon.getDonVi());
            txtDonGia.setText(String.valueOf(mon.getDonGia()));
        } else {
            MsgBox.alert(this, "Không tìm thấy thông tin món ăn!");
        }
    }

    MonAn getFormMonAn() {
        MonAn entity = new MonAn();

        entity.setMaMon(txtMaMon.getText().trim());
        entity.setTenMon(txtTenMon.getText().trim());

        String maLoaiMon = String.valueOf(daoLM.selectByName((String) cboLoaiMon.getSelectedItem()).getMaLoaiMon());
        entity.setMaLoaiMon(maLoaiMon);

        entity.setDonVi(txtDonVi.getText().trim());
        entity.setDonGia(Float.parseFloat(txtDonGia.getText().trim()));
        return entity;
    }

    PhieuNhapDAO daoPN = new PhieuNhapDAO();
    NhaCungCapDAO daoCC = new NhaCungCapDAO();

    void resetFormPhieuNhap() {
        this.txtMaPhieuNhap.setText("");
        this.txtNgayLapPhieu.setText("");
        this.txtNgayNhap.setText("");
        this.cboNguoiNhap.setSelectedIndex(0);
        this.cboNhaCungCap.setSelectedIndex(0);
    }

    void setFormPhieuNhap(String id) {
        PhieuNhap pn = daoPN.selectById(id);
        if (pn != null) {
            this.txtMaPhieuNhap.setText(pn.getMaPhieuNhap());
            this.txtNgayLapPhieu.setText(XDate.toString(pn.getNgayLapPhieu(), "dd-MM-yyyy"));
            this.txtNgayNhap.setText(XDate.toString(pn.getNgayNhap(), "dd-MM-yyyy"));
            String hoTenNV = daoNV.selectById(pn.getMaNV()).getHoTenNV();
            this.cboNguoiNhap.setSelectedItem(hoTenNV);
            String tenCC = daoCC.selectById(pn.getMaCC()).getTenCC();
            this.cboNhaCungCap.setSelectedItem(tenCC);
        } else {
            MsgBox.alert(this, "Không tìm thấy thông tin phiếu nhập!");
        }
    }

    PhieuNhap getFormPhieuNhap() {
        PhieuNhap entity = new PhieuNhap();
        entity.setMaPhieuNhap(txtMaPhieuNhap.getText().trim());
        entity.setNgayLapPhieu(XDate.toDate(txtNgayLapPhieu.getText().trim(), "yyyy-MM-dd"));
        entity.setNgayNhap(XDate.toDate(txtNgayNhap.getText().trim(), "yyyy-MM-dd"));
        String maNV = daoNV.selectByName(String.valueOf(cboNguoiNhap.getSelectedItem())).getMaNV();
        entity.setMaNV(maNV);
        String maCC = daoCC.selectByName(String.valueOf(cboNhaCungCap.getSelectedItem())).getMaCC();
        entity.setMaCC(maCC);
        return entity;
    }

    PhieuNhapCTDAO daoPNCT = new PhieuNhapCTDAO();
    NguyenLieuDAO daoNL = new NguyenLieuDAO();

    void resetFormPhieuNhapCT() {
        this.cboMaPhieuNhap.setSelectedIndex(0);
        this.cboTenNguyenLieu.setSelectedIndex(0);
        this.txtDonGiaNgLieu.setText("");
        this.txtDonViNgLieu.setText("");
        this.txtSoLuongNgLieu.setText("");
    }

    void setFormPhieuNhapCT(String id) {
        PhieuNhapCT pnct = daoPNCT.selectById(id);
        if (pnct != null) {
            this.cboMaPhieuNhap.setSelectedItem(pnct.getMaPhieuNhap());
            String tenNgLieu = daoNL.selectById(pnct.getMaNgLieu()).getTenNgLieu();
            this.cboTenNguyenLieu.setSelectedItem(tenNgLieu);
            this.txtDonGiaNgLieu.setText("");
            this.txtDonViNgLieu.setText("");
            this.txtSoLuongNgLieu.setText("");
        } else {
            MsgBox.alert(this, "Không tìm thấy thông tin phiếu nhập chi tiết!");
        }
    }

    PhieuNhapCT getFormPhieuNhapCT() {
        PhieuNhapCT entity = new PhieuNhapCT();

        entity.setMaPhieuNhap((String) cboMaPhieuNhap.getSelectedItem());
        String maNgLieu = daoNL.selectByName((String) cboTenNguyenLieu.getSelectedItem()).getMaNgLieu();
        entity.setMaNgLieu(maNgLieu);
        entity.setDonGia(Float.parseFloat(txtDonGiaNgLieu.getText().trim()));
        entity.setDonVi(txtDonViNgLieu.getText().trim());
        entity.setSoLuong(Float.parseFloat(txtSoLuongNgLieu.getText().trim()));
        return entity;
    }

    LoaiNgLieuDAO daoLNL = new LoaiNgLieuDAO();

    void resetFormNguyenLieu() {
        this.txtMaNgLieu.setText("");
        this.txtTenNgLieu.setText("");
        this.cboLoaiNguyenLieu.setSelectedIndex(0);
        this.txtDonViNguyenLieu.setText("");
        this.txtSoLuongNguyenLieu.setText("");
    }

    void setFormNguyenLieu(String name) {
        NguyenLieu nl = daoNL.selectByName(name);
        if (nl != null) {
            this.txtMaNgLieu.setText(nl.getMaNgLieu());
            this.txtTenNgLieu.setText(nl.getTenNgLieu());
            String loaiNguyenLieu = daoLNL.selectById(nl.getMaLoaiNgLieu()).getTenLoaiNgLieu();
            this.cboLoaiNguyenLieu.setSelectedItem(loaiNguyenLieu);
            this.txtDonViNguyenLieu.setText(nl.getDonVi());
            this.txtSoLuongNguyenLieu.setText(String.valueOf(nl.getSoLuong()));
        } else {
            MsgBox.alert(this, "Không tìm thấy thông tin nguyên liệu!");
        }
    }

    NguyenLieu getFormNguyenLieu() {
        NguyenLieu entity = new NguyenLieu();
        entity.setMaNgLieu(txtMaNgLieu.getText().trim());
        entity.setTenNgLieu(txtTenNgLieu.getText().trim());
        String maLoaiNgLieu = daoNL.selectByName(cboLoaiNguyenLieu.getSelectedItem().toString()).getMaLoaiNgLieu();
        entity.setMaLoaiNgLieu(maLoaiNgLieu);
        entity.setDonVi(txtDonViNguyenLieu.getText().trim());
        entity.setSoLuong(Float.parseFloat(txtSoLuongNguyenLieu.getText().trim()));
        return entity;
    }

    CongThucDAO daoCT = new CongThucDAO();

    void resetFormCongThuc() {
        txtMaMonAuto.setText("");
        cboTenMon.setSelectedIndex(0);
        cboNguyenLieu.setSelectedIndex(0);
        txtDonViAuto.setText("");
        txtSoLuong.setText("");
    }

    CongThuc getFormCongThuc() {
        CongThuc entity = new CongThuc();
        entity.setMaMon(txtMaMonAuto.getText().trim());
        String maNgLieu = daoNL.selectByName(cboNguyenLieu.getSelectedItem().toString()).getMaLoaiNgLieu();
        entity.setMaNgLieu(maNgLieu);
        entity.setDonVi(txtDonViAuto.getText().trim());
        entity.setSoLuong(Float.parseFloat(txtSoLuong.getText().trim()));

        return entity;
    }

    int rowNV = -1; // Biến lưu hàng đang được chọn hiện tại trên bảng
    int rowMA = -1; // Biến lưu hàng đang được chọn hiện tại trên bảng
    int rowPN = -1; // Biến lưu hàng đang được chọn hiện tại trên bảng
    int rowNL = -1; // Biến lưu hàng đang được chọn hiện tại trên bảng
    int rowCT = -1; // Biến lưu hàng đang được chọn hiện tại trên bảng

    void updateStatusNhanVien() {
        boolean edit = (this.rowNV >= 0);
//        boolean first = (this.rowNV == 0);
//        boolean last = (this.rowNV == tblNhanVien.getRowCount() - 1);
        // Trạng thái form
//        txtMaNV.setEditable(edit);
        btnAddNhanVien.setEnabled(edit);
        btnUpdateNhanVien.setEnabled(edit);
        btnDeleteNhanVien.setEnabled(edit);
        // Trạng thái điều hướng
//        btnFirst.setEnabled(edit && !first); // Nếu row >= 0 và không nằm ở đầu bảng
//        btnPrev.setEnabled(edit && !first); // Nếu row >= 0 và không nằm ở đầu bảng
//        btnNext.setEnabled(edit && !last); // Nếu row >= 0 và không nằm ở cuối bảng
//        btnLast.setEnabled(edit && !last); // Nếu row >= 0 và không nằm ở cuối bảng
    }

    void chonAnh(JLabel lblHinh) {
        /* - Khi người dụng click vào "chọn ảnh" trên form, hộp thoại cho phép chọn hình ảnh được hiện ra.
           - Sau khi chọn hình ảnh, getAbsolutePath() sẽ giúp lấy đường dẫn tuyệt đối của file 
             và lưu vào biến toàn cục pathImg có kiểu dữ liệu  String */
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            XImage.save(file); // luu hinh vao thu muc logos
            ImageIcon icon = XImage.read(file.getName()); // doc hinh tu logos
//            icon.getScaledInstance(lblHinh.getWidth(), lblHinh.getHeight(), Image.SCALE_SMOOTH);
            lblHinh.setIcon(icon);
            lblHinh.setToolTipText(file.getName()); // giu ten hinh trong tooltip
            lblHinh.setText("");
        }
    }

}
