package ui;

//package ui;
import controllers.QLThongKe;
import utils.XInit;
import controllers.QLNhanVien;
import dao.CaTrucDAO;
import dao.HoaDonDAO;
import dao.KhachHangDAO;
import dao.NguyenLieuDAO;
import dao.NhanVienDAO;
import dao.PhieuNhapDAO;
import model.CaTruc;
import model.KhachHang;
import model.NguyenLieu;
import model.NhanVien;
import model.PhieuNhap;
import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import utils.Auth;
import utils.MsgBox;
import utils.OutputExcel;

public class ThongKe extends javax.swing.JFrame {

    public ThongKe() {
        initComponents();
        XInit.init(this);
        QLNhanVien.fillComboBoxNhanVien(cboThongKe);
        init();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlTool = new javax.swing.JPanel();
        pnlTimkiem = new javax.swing.JPanel();
        cboThongKe = new javax.swing.JComboBox<>();
        pnlSapxep = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cboChoncot = new javax.swing.JComboBox<>();
        cboSapxeptheo = new javax.swing.JComboBox<>();
        btnXemchitiet = new javax.swing.JButton();
        btnXuatfile = new javax.swing.JButton();
        btnAddPhieuNhap2 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        tabs = new javax.swing.JTabbedPane();
        pnlNhanvien = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblNhanVien = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        rdoNam = new javax.swing.JRadioButton();
        rdoNu = new javax.swing.JRadioButton();
        jSpinner1 = new javax.swing.JSpinner();
        jSpinner2 = new javax.swing.JSpinner();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        pnlCatruc = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblCaTruc = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jSpinner3 = new javax.swing.JSpinner();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        pnlKhachhang = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblKhachHang = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        rdoNam1 = new javax.swing.JRadioButton();
        rdoNu1 = new javax.swing.JRadioButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jLabel14 = new javax.swing.JLabel();
        pnlHoadon = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblHoaDon = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jComboBox6 = new javax.swing.JComboBox<>();
        jComboBox7 = new javax.swing.JComboBox<>();
        jComboBox8 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        pnlPhieunhap = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblPhieuNhap = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jComboBox9 = new javax.swing.JComboBox<>();
        jComboBox10 = new javax.swing.JComboBox<>();
        jComboBox11 = new javax.swing.JComboBox<>();
        jTextField2 = new javax.swing.JTextField();
        pnlPhieuNhapCT = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        pnlNguyenlieu = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblNguyenLieu = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jComboBox12 = new javax.swing.JComboBox<>();
        jTextField3 = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnDanhmuc = new javax.swing.JMenu();
        mnThemmoi = new javax.swing.JMenu();
        mnThongke = new javax.swing.JMenu();
        mnExit = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Quản Lý Nhà Hàng");
        setName(""); // NOI18N
        setResizable(false);
        setSize(new java.awt.Dimension(721, 406));

        pnlTool.setBackground(new java.awt.Color(255, 255, 204));
        pnlTool.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 0, new java.awt.Color(255, 204, 102)));

        pnlTimkiem.setBackground(new java.awt.Color(255, 204, 102));
        pnlTimkiem.setBorder(javax.swing.BorderFactory.createTitledBorder("Tìm Kiếm"));

        cboThongKe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout pnlTimkiemLayout = new javax.swing.GroupLayout(pnlTimkiem);
        pnlTimkiem.setLayout(pnlTimkiemLayout);
        pnlTimkiemLayout.setHorizontalGroup(
            pnlTimkiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cboThongKe, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnlTimkiemLayout.setVerticalGroup(
            pnlTimkiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTimkiemLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cboThongKe, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlSapxep.setBackground(new java.awt.Color(255, 204, 102));
        pnlSapxep.setBorder(javax.swing.BorderFactory.createTitledBorder("Sắp Xếp"));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel1.setText("Chọn Cột");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel2.setText("Sắp Xếp Theo");

        cboChoncot.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboChoncot.setMaximumSize(new java.awt.Dimension(72, 26));
        cboChoncot.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboChoncotItemStateChanged(evt);
            }
        });

        cboSapxeptheo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tăng", "Giảm" }));
        cboSapxeptheo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboSapxeptheoItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout pnlSapxepLayout = new javax.swing.GroupLayout(pnlSapxep);
        pnlSapxep.setLayout(pnlSapxepLayout);
        pnlSapxepLayout.setHorizontalGroup(
            pnlSapxepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSapxepLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlSapxepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlSapxepLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboSapxeptheo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlSapxepLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboChoncot, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        pnlSapxepLayout.setVerticalGroup(
            pnlSapxepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSapxepLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlSapxepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cboChoncot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlSapxepLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cboSapxeptheo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        btnXemchitiet.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnXemchitiet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/info-2-32.png"))); // NOI18N
        btnXemchitiet.setText("Chi Tiết");
        btnXemchitiet.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnXemchitiet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXemchitietActionPerformed(evt);
            }
        });

        btnXuatfile.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnXuatfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/download-2-32.png"))); // NOI18N
        btnXuatfile.setText("Xuất File");

        btnAddPhieuNhap2.setBackground(new java.awt.Color(51, 153, 255));
        btnAddPhieuNhap2.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        btnAddPhieuNhap2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/add-list-32.png"))); // NOI18N
        btnAddPhieuNhap2.setText("Thêm");

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/user-3-128.png"))); // NOI18N

        javax.swing.GroupLayout pnlToolLayout = new javax.swing.GroupLayout(pnlTool);
        pnlTool.setLayout(pnlToolLayout);
        pnlToolLayout.setHorizontalGroup(
            pnlToolLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlToolLayout.createSequentialGroup()
                .addGroup(pnlToolLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlToolLayout.createSequentialGroup()
                        .addGroup(pnlToolLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlToolLayout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addGroup(pnlToolLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(pnlTimkiem, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pnlSapxep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(pnlToolLayout.createSequentialGroup()
                                .addGap(66, 66, 66)
                                .addComponent(btnXuatfile, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlToolLayout.createSequentialGroup()
                                .addGap(62, 62, 62)
                                .addComponent(jLabel9)))
                        .addGap(0, 11, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlToolLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnAddPhieuNhap2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnXemchitiet)))
                .addContainerGap())
        );
        pnlToolLayout.setVerticalGroup(
            pnlToolLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlToolLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(pnlTimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlSapxep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlToolLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddPhieuNhap2)
                    .addComponent(btnXemchitiet))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnXuatfile)
                .addGap(13, 13, 13))
        );

        tabs.setBackground(new java.awt.Color(255, 204, 102));
        tabs.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(255, 204, 102)));
        tabs.setMaximumSize(new java.awt.Dimension(546, 332));
        tabs.setMinimumSize(new java.awt.Dimension(546, 332));
        tabs.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                tabsStateChanged(evt);
            }
        });
        tabs.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tabsKeyPressed(evt);
            }
        });

        pnlNhanvien.setBackground(new java.awt.Color(255, 255, 204));
        pnlNhanvien.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                pnlNhanvienComponentShown(evt);
            }
        });

        tblNhanVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã NV", "Họ Tên NV", "Giới Tính", "Số ĐT", "Địa Chỉ", "Chức Vụ ", "Ca trực", "Lương", "Mật Khẩu"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblNhanVien);
        if (tblNhanVien.getColumnModel().getColumnCount() > 0) {
            tblNhanVien.getColumnModel().getColumn(0).setResizable(false);
            tblNhanVien.getColumnModel().getColumn(1).setResizable(false);
            tblNhanVien.getColumnModel().getColumn(2).setResizable(false);
            tblNhanVien.getColumnModel().getColumn(3).setResizable(false);
            tblNhanVien.getColumnModel().getColumn(4).setResizable(false);
            tblNhanVien.getColumnModel().getColumn(5).setResizable(false);
            tblNhanVien.getColumnModel().getColumn(7).setResizable(false);
            tblNhanVien.getColumnModel().getColumn(8).setResizable(false);
        }

        jPanel7.setBackground(new java.awt.Color(255, 204, 102));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel3.setText("Giới tính:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel4.setText("Mức lương:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel5.setText("Ca trực");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel6.setText("Chức vụ:");

        rdoNam.setSelected(true);
        rdoNam.setText("Nam");

        rdoNu.setText("Nữ");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel7.setText("Từ:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel8.setText("Đến:");

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(39, 39, 39)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(rdoNam)
                        .addGap(9, 9, 9)
                        .addComponent(rdoNu)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(rdoNam)
                    .addComponent(rdoNu)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7)
                        .addComponent(jLabel8)))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlNhanvienLayout = new javax.swing.GroupLayout(pnlNhanvien);
        pnlNhanvien.setLayout(pnlNhanvienLayout);
        pnlNhanvienLayout.setHorizontalGroup(
            pnlNhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNhanvienLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlNhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 738, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlNhanvienLayout.setVerticalGroup(
            pnlNhanvienLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNhanvienLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        tabs.addTab("Nhân Viên", pnlNhanvien);

        pnlCatruc.setBackground(new java.awt.Color(255, 255, 204));
        pnlCatruc.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                pnlCatrucComponentShown(evt);
            }
        });

        tblCaTruc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane6.setViewportView(tblCaTruc);

        jPanel4.setBackground(new java.awt.Color(255, 204, 102));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Lọc"));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel10.setText("Chọn ngày");

        jLabel11.setText("Chọn số lượng");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel12.setText("Ca trực");

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel12)
                        .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlCatrucLayout = new javax.swing.GroupLayout(pnlCatruc);
        pnlCatruc.setLayout(pnlCatrucLayout);
        pnlCatrucLayout.setHorizontalGroup(
            pnlCatrucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCatrucLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCatrucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 738, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlCatrucLayout.setVerticalGroup(
            pnlCatrucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCatrucLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabs.addTab("Ca Trực", pnlCatruc);

        pnlKhachhang.setBackground(new java.awt.Color(255, 255, 204));
        pnlKhachhang.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                pnlKhachhangComponentShown(evt);
            }
        });

        tblKhachHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(tblKhachHang);

        jPanel6.setBackground(new java.awt.Color(255, 204, 102));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Lọc"));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel13.setText("Giới tính:");

        rdoNam1.setSelected(true);
        rdoNam1.setText("Nam");

        rdoNu1.setText("Nữ");

        jCheckBox1.setText("Năm Sinh");

        jCheckBox2.setText("Tháng Sinh");

        jCheckBox3.setText("Ngày Sinh");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        jLabel14.setText("Sinh nhật:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rdoNam1)
                .addGap(9, 9, 9)
                .addComponent(rdoNu1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox1)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox1)
                    .addComponent(jCheckBox2)
                    .addComponent(jCheckBox3)
                    .addComponent(jLabel14)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(rdoNam1)
                        .addComponent(rdoNu1)))
                .addGap(0, 9, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlKhachhangLayout = new javax.swing.GroupLayout(pnlKhachhang);
        pnlKhachhang.setLayout(pnlKhachhangLayout);
        pnlKhachhangLayout.setHorizontalGroup(
            pnlKhachhangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKhachhangLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlKhachhangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlKhachhangLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 738, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlKhachhangLayout.setVerticalGroup(
            pnlKhachhangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKhachhangLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        tabs.addTab("Khách Hàng", pnlKhachhang);

        pnlHoadon.setBackground(new java.awt.Color(255, 255, 204));
        pnlHoadon.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                pnlHoadonComponentShown(evt);
            }
        });

        tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(tblHoaDon);

        jPanel1.setBackground(new java.awt.Color(255, 204, 102));

        jButton3.setText("Tổng");

        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Theo Ngày", "Item 2", "Item 3", "Item 4" }));

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Theo Người Lập", "Item 2", "Item 3", "Item 4" }));

        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Theo Khách Hàng", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlHoadonLayout = new javax.swing.GroupLayout(pnlHoadon);
        pnlHoadon.setLayout(pnlHoadonLayout);
        pnlHoadonLayout.setHorizontalGroup(
            pnlHoadonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHoadonLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlHoadonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 738, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlHoadonLayout.setVerticalGroup(
            pnlHoadonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHoadonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        tabs.addTab("Hóa Đơn", pnlHoadon);

        pnlPhieunhap.setBackground(new java.awt.Color(255, 255, 204));
        pnlPhieunhap.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                pnlPhieunhapComponentShown(evt);
            }
        });

        tblPhieuNhap.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tblPhieuNhap);

        jPanel5.setBackground(new java.awt.Color(255, 204, 102));

        jButton4.setText("Tổng");

        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Theo Ngày", "Item 2", "Item 3", "Item 4" }));

        jComboBox10.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Theo Người Lập", "Item 2", "Item 3", "Item 4" }));

        jComboBox11.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Theo Nguyên Liệu", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jComboBox9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlPhieunhapLayout = new javax.swing.GroupLayout(pnlPhieunhap);
        pnlPhieunhap.setLayout(pnlPhieunhapLayout);
        pnlPhieunhapLayout.setHorizontalGroup(
            pnlPhieunhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPhieunhapLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlPhieunhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 738, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlPhieunhapLayout.setVerticalGroup(
            pnlPhieunhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPhieunhapLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabs.addTab("Phiếu Nhập", pnlPhieunhap);

        pnlPhieuNhapCT.setBackground(new java.awt.Color(255, 255, 204));

        jPanel3.setBackground(new java.awt.Color(255, 204, 102));

        jButton1.setText("Phiếu Nhập");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane7.setViewportView(jTable1);

        javax.swing.GroupLayout pnlPhieuNhapCTLayout = new javax.swing.GroupLayout(pnlPhieuNhapCT);
        pnlPhieuNhapCT.setLayout(pnlPhieuNhapCTLayout);
        pnlPhieuNhapCTLayout.setHorizontalGroup(
            pnlPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 750, Short.MAX_VALUE)
        );
        pnlPhieuNhapCTLayout.setVerticalGroup(
            pnlPhieuNhapCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPhieuNhapCTLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 408, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabs.addTab("Chi Tiết Phiếu Nhập", pnlPhieuNhapCT);

        pnlNguyenlieu.setBackground(new java.awt.Color(255, 255, 204));
        pnlNguyenlieu.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                pnlNguyenlieuComponentShown(evt);
            }
        });

        tblNguyenLieu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(tblNguyenLieu);

        jPanel2.setBackground(new java.awt.Color(255, 204, 102));

        jButton5.setText("Tổng");

        jComboBox12.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Theo Nguyên Liệu", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(jComboBox12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField3)
                .addContainerGap())
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(646, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(jButton5)
                    .addContainerGap(17, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout pnlNguyenlieuLayout = new javax.swing.GroupLayout(pnlNguyenlieu);
        pnlNguyenlieu.setLayout(pnlNguyenlieuLayout);
        pnlNguyenlieuLayout.setHorizontalGroup(
            pnlNguyenlieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNguyenlieuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlNguyenlieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 738, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnlNguyenlieuLayout.setVerticalGroup(
            pnlNguyenlieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlNguyenlieuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabs.addTab("Nguyên Liệu", pnlNguyenlieu);

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jMenuBar1.setMaximumSize(new java.awt.Dimension(710, 29));
        jMenuBar1.setMinimumSize(new java.awt.Dimension(710, 29));
        jMenuBar1.setPreferredSize(new java.awt.Dimension(710, 29));

        mnDanhmuc.setText("Danh Mục");
        mnDanhmuc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mnDanhmucMouseClicked(evt);
            }
        });
        jMenuBar1.add(mnDanhmuc);

        mnThemmoi.setText("Thêm Mới");
        mnThemmoi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mnThemmoiMouseClicked(evt);
            }
        });
        jMenuBar1.add(mnThemmoi);

        mnThongke.setBackground(new java.awt.Color(0, 102, 255));
        mnThongke.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        mnThongke.setForeground(new java.awt.Color(255, 255, 255));
        mnThongke.setText("Thống Kê");
        mnThongke.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jMenuBar1.add(mnThongke);

        mnExit.setText("Thoát");
        mnExit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mnExitMouseClicked(evt);
            }
        });
        jMenuBar1.add(mnExit);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlTool, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tabs, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlTool, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tabs, javax.swing.GroupLayout.PREFERRED_SIZE, 513, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        tabs.getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tabsKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabsKeyPressed

    }//GEN-LAST:event_tabsKeyPressed

    private void pnlNhanvienComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_pnlNhanvienComponentShown
//        fillChoncot(tblNhanVien);
    }//GEN-LAST:event_pnlNhanvienComponentShown

    private void pnlHoadonComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_pnlHoadonComponentShown
//        fillChoncot(tblHoaDon);
    }//GEN-LAST:event_pnlHoadonComponentShown

    private void cboChoncotItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboChoncotItemStateChanged
//        if(pnlNhanvien.isShowing())
//        {
//            this.showtableNhanvien();
//        }
//        else if(pnlHoadon.isShowing())
//        {
//            this.showtableHoaDon();
//        }
//        else if(pnlPhieunhap.isShowing())
//        {
//            this.showTablephieunhap();
//        }
//        else if(pnlCatruc.isShowing())
//        {
//            this.showTablencatruc();
//        }
//        else if(pnlKhachhang.isShowing())
//        {
//            this.showTablenkhachhang();
//        }
//        else if(pnlNguyenlieu.isShowing())
//        {
//            this.showTablenguyenlieu();
//        }

    }//GEN-LAST:event_cboChoncotItemStateChanged

    private void cboSapxeptheoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboSapxeptheoItemStateChanged
//        if(pnlNhanvien.isShowing())
//        {
//            this.showtableNhanvien();
//        }
//        else if(pnlHoadon.isShowing())
//        {
//            this.showtableHoaDon();
//        }
//        else if(pnlPhieunhap.isShowing())
//        {
//            this.showTablephieunhap();
//        }
//        else if(pnlCatruc.isShowing())
//        {
//            this.showTablencatruc();
//        }
//        else if(pnlKhachhang.isShowing())
//        {
//            this.showTablenkhachhang();
//        }
//        else if(pnlNguyenlieu.isShowing())
//        {
//            this.showTablenguyenlieu();
//        }
    }//GEN-LAST:event_cboSapxeptheoItemStateChanged

    private void btnXemchitietActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXemchitietActionPerformed
//        if(pnlNhanvien.isShowing())
//        {
//            DefaultTableModel model = (DefaultTableModel) tblNhanVien.getModel();
//            OutputExcel out = new OutputExcel("NhanVien", model);
//        }
//        else if(pnlHoadon.isShowing())
//        {
//            DefaultTableModel model = (DefaultTableModel) tblHoadon.getModel();
//            OutputExcel out = new OutputExcel("HoaDon", model);
//        }
//        else if(pnlPhieunhap.isShowing())
//        {
//            DefaultTableModel model = (DefaultTableModel) tblNguyenLieu.getModel();
//            OutputExcel out = new OutputExcel("NguyenLieu", model);
//        }
//        else if(pnlCatruc.isShowing())
//        {
//            DefaultTableModel model = (DefaultTableModel) tblCaTruc.getModel();
//            OutputExcel out = new OutputExcel("CaTruc", model);
//        }
//        else if(pnlKhachhang.isShowing())
//        {
//            DefaultTableModel model = (DefaultTableModel) tblKhachhang.getModel();
//            OutputExcel out = new OutputExcel("Khachhang", model);
//        }
//        else if(pnlNguyenlieu.isShowing())
//        {
//            DefaultTableModel model = (DefaultTableModel) tblNguyenLieu.getModel();
//            OutputExcel out = new OutputExcel("HoaDon", model);
//        }
    }//GEN-LAST:event_btnXemchitietActionPerformed

    private void pnlPhieunhapComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_pnlPhieunhapComponentShown
//        this.showTablephieunhap();
    }//GEN-LAST:event_pnlPhieunhapComponentShown

    private void pnlNguyenlieuComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_pnlNguyenlieuComponentShown
//        this.showTablenguyenlieu();
    }//GEN-LAST:event_pnlNguyenlieuComponentShown

    private void pnlKhachhangComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_pnlKhachhangComponentShown
//        this.showTablenkhachhang();
    }//GEN-LAST:event_pnlKhachhangComponentShown

    private void pnlCatrucComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_pnlCatrucComponentShown
//        this.showTablencatruc();
    }//GEN-LAST:event_pnlCatrucComponentShown

    private void tabsStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_tabsStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_tabsStateChanged

    private void mnDanhmucMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mnDanhmucMouseClicked
        // TODO add your handling code here:
        String maCV = Auth.user.getMaCV();
        if (Auth.isLogin()) {
            if (null != maCV) {
                switch (maCV) {
                    case "CV001":
                        DanhMucQuanLy quanLy = new DanhMucQuanLy();
                        quanLy.setVisible(true);
                        break;
                    case "CV002":
                        new DanhMucThuNgan().setVisible(true);
                        break;
                    case "CV003":
                        new DanhMucDauBep().setVisible(true);
                        break;
                    default:
                        break;
                }
            }
        }
        this.dispose();
    }//GEN-LAST:event_mnDanhmucMouseClicked

    private void mnExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mnExitMouseClicked
        // TODO add your handling code here:
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mnExitMouseClicked

    private void mnThemmoiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mnThemmoiMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_mnThemmoiMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                if (!Auth.isLogin()) {
                    new Login().setVisible(true);
                    MsgBox.alert(null, "Vui lòng đăng nhập!");
                } else {
                    new ThongKe().setVisible(true);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddPhieuNhap2;
    private javax.swing.JButton btnXemchitiet;
    private javax.swing.JButton btnXuatfile;
    private javax.swing.JComboBox<String> cboChoncot;
    private javax.swing.JComboBox<String> cboSapxeptheo;
    private javax.swing.JComboBox<String> cboThongKe;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox10;
    private javax.swing.JComboBox<String> jComboBox11;
    private javax.swing.JComboBox<String> jComboBox12;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JMenu mnDanhmuc;
    private javax.swing.JMenu mnExit;
    private javax.swing.JMenu mnThemmoi;
    private javax.swing.JMenu mnThongke;
    private javax.swing.JPanel pnlCatruc;
    private javax.swing.JPanel pnlHoadon;
    private javax.swing.JPanel pnlKhachhang;
    private javax.swing.JPanel pnlNguyenlieu;
    private javax.swing.JPanel pnlNhanvien;
    private javax.swing.JPanel pnlPhieuNhapCT;
    private javax.swing.JPanel pnlPhieunhap;
    private javax.swing.JPanel pnlSapxep;
    private javax.swing.JPanel pnlTimkiem;
    private javax.swing.JPanel pnlTool;
    private javax.swing.JRadioButton rdoNam;
    private javax.swing.JRadioButton rdoNam1;
    private javax.swing.JRadioButton rdoNu;
    private javax.swing.JRadioButton rdoNu1;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JTable tblCaTruc;
    private javax.swing.JTable tblHoaDon;
    private javax.swing.JTable tblKhachHang;
    private javax.swing.JTable tblNguyenLieu;
    private javax.swing.JTable tblNhanVien;
    private javax.swing.JTable tblPhieuNhap;
    // End of variables declaration//GEN-END:variables

    NhanVienDAO NVdao = new NhanVienDAO();
    HoaDonDAO HDdao = new HoaDonDAO();
    PhieuNhapDAO PNDAO = new PhieuNhapDAO();
    NguyenLieuDAO NLDao = new NguyenLieuDAO();
    KhachHangDAO KHDao = new KhachHangDAO();
    CaTrucDAO CTDao = new CaTrucDAO();

    NhanVien nhanVien = new NhanVien();
    model.HoaDon hoaDon = new model.HoaDon();
    PhieuNhap phieuNhap = new PhieuNhap();
    NguyenLieu nguyenLieu = new NguyenLieu();
    KhachHang khachHang = new KhachHang();
    CaTruc caTruc = new CaTruc();

//    private void WatterMake(JTextField searchText, String chuoi) {
//        searchText.setForeground(Color.GRAY);
//        searchText.setText(chuoi);
//        searchText.addFocusListener(new FocusListener() {
//            @Override
//            public void focusGained(FocusEvent e) 
//            {
//                if (searchText.getText().equals(chuoi)) 
//                {
//                    searchText.setText("");
//                    searchText.setForeground(Color.BLACK);
//                }
//            }
//            @Override
//            public void focusLost(FocusEvent e) 
//            {
//                if (searchText.getText().isEmpty()) 
//                {
//                    searchText.setForeground(Color.GRAY);
//                    searchText.setText(chuoi);
//                }
//            }
//            });
//    }
//    public void showtableNhanvien()
//    {
//        DefaultTableModel model = (DefaultTableModel) tblNhanVien.getModel();
//        model.setRowCount(0);
//        if(cboChoncot.getItemCount()<1 )
//        {
//            try {
//                List<NhanVien> list = NVdao.selectAll();
//                for (NhanVien nv : list) {
//                    Object[] row = {
//                        nv.getMaNV(),
//                        nv.getHoTen(),
//                        nv.getGioiTinh(),
//                        nv.getsDt(),
//                        nv.getDiaChi(),
//                        nv.getMaCv(),
//                        nv.getMaCatruc(),
//                        nv.getLuong(),
//                        nv.getMatKhau()
//                    };
//                    model.addRow(row);  
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//        else{
//            try {
//                String a;
//                if(cboSapxeptheo.getSelectedItem().equals("Tăng"))
//                {
//                    a = "ASC";
//                }
//                else{
//                    a= "DESC";
//                }
//
//                List<NhanVien> listnv = NVdao.selectAllbyentity(nhanVien.getEntity().get(cboChoncot.getSelectedIndex()),a);
//                for (NhanVien nv : listnv) {
//                    Object[] row = {
//                        nv.getMaNV(),
//                        nv.getHoTen(),
//                        nv.getGioiTinh(),
//                        nv.getsDt(),
//                        nv.getDiaChi(),
//                        nv.getMaCv(),
//                        nv.getMaCatruc(),
//                        nv.getLuong(),
//                        nv.getMatKhau()
//                    };
//                    model.addRow(row);   
//                    
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//    }
//    public void showTablephieunhap()
//    {
//        DefaultTableModel model = (DefaultTableModel) tblPhieuNhap.getModel();
//        model.setRowCount(0);
//        if(cboChoncot.getItemCount()<1 )
//        {
//            try {
//                List<PhieuNhap> list = PNDAO.selectAll();
//                for (PhieuNhap pn : list) {
//                    Object[] row = {
//                        pn.getMaPhieuNhap(),pn.getMaNgLieu(),pn.getDonGia(),pn.getDonViTinh(),pn.getSoluong(),
//                        pn.getNgayLapPhieu(),pn.getNgayNhap(),pn.getMaCC(),pn.getMaNV()
//                    };
//                    model.addRow(row);  
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//        else{
//            try {
//                String a;
//                if(cboSapxeptheo.getSelectedItem().equals("Tăng"))
//                {
//                    a = "ASC";
//                }
//                else{
//                    a= "DESC";
//                }
//
//                List<PhieuNhap> listnv = PNDAO.selectAllbyentity(phieuNhap.getEntity().get(cboChoncot.getSelectedIndex()),a);
//                for (PhieuNhap pn : listnv) {
//                    Object[] row = {
//                        pn.getMaPhieuNhap(),pn.getMaNgLieu(),pn.getDonGia(),pn.getDonViTinh(),pn.getSoluong(),
//                        pn.getNgayLapPhieu(),pn.getNgayNhap(),pn.getMaCC(),pn.getMaNV()
//                    };
//                    model.addRow(row);   
//                    
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//    }
//    public void showtableHoaDon()
//    {
//        DefaultTableModel model = (DefaultTableModel) tblHoaDon.getModel();
//        model.setRowCount(0);
//        if(cboChoncot.getItemCount()<1 )
//        {
//            try {
//                List<model.HoaDon> list = HDdao.selectAll();
//                for (model.HoaDon a : list) {
//                Object[] row = {
//                    a.getMaHoaDon(),
//                    a.getNgayLapHD(),
//                    a.getMaNV(),
//                    a.getHinhThucTT(),
//                    a.getMaKH()
//                    };
//                    model.addRow(row);
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//        else{
//            try {
//                String a;
//                if(cboSapxeptheo.getSelectedItem().equals("Tăng"))
//                {
//                    a = "ASC";
//                }
//                else{
//                    a= "DESC";
//                }
//                List<model.HoaDon> list = HDdao.selectAllbyentity(hoaDon.getEntity().get(cboChoncot.getSelectedIndex()), a);
//                for (model.HoaDon b : list) 
//                {
//                    Object[] row = {
//                        b.getMaHoaDon(),
//                        b.getNgayLapHD(),
//                        b.getMaNV(),
//                        b.getHinhThucTT(),
//                        b.getMaKH()
//                        };
//                    model.addRow(row);
//                }    
//                
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//    }
//    public void showTablenguyenlieu()
//    {
//        DefaultTableModel model = (DefaultTableModel) tblNguyenLieu.getModel();
//        model.setRowCount(0);
//        if(cboChoncot.getItemCount()<1 )
//        {
//            try {
//                List<NguyenLieu> list = NLDao.selectAll();
//                for (NguyenLieu pn : list) {
//                    Object[] row = {
//                        pn.getManguyenlieu(),pn.getTenNguyenLieu()
//                    };
//                    model.addRow(row);  
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//        else{
//            try {
//                String a;
//                if(cboSapxeptheo.getSelectedItem().equals("Tăng"))
//                {
//                    a = "ASC";
//                }
//                else{
//                    a= "DESC";
//                }
//
//                List<NguyenLieu> listnv = NLDao.selectAllbyentity(nguyenLieu.getEntity().get(cboChoncot.getSelectedIndex()),a);
//                for (NguyenLieu pn : listnv) {
//                    Object[] row = {
//                        pn.getManguyenlieu(),pn.getTenNguyenLieu()
//                    };
//                    model.addRow(row);   
//                    
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//    }
//    public void showTablenkhachhang()
//    {
//        DefaultTableModel model = (DefaultTableModel) tblKhachHang.getModel();
//        model.setRowCount(0);
//        if(cboChoncot.getItemCount()<1 )
//        {
//            try {
//                List<KhachHang> list = KHDao.selectAll();
//                for (KhachHang pn : list) {
//                    Object[] row = {
//                        pn.getMaKH(),pn.getHoTenKH(),pn.getSoDT(),pn.getDiaChi()
//                    };
//                    model.addRow(row);  
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//        else{
//            try {
//                String a;
//                if(cboSapxeptheo.getSelectedItem().equals("Tăng"))
//                {
//                    a = "ASC";
//                }
//                else{
//                    a= "DESC";
//                }
//
//                List<KhachHang> listnv = KHDao.selectAllbyentity(khachHang.getEntity().get(cboChoncot.getSelectedIndex()),a);
//                for (KhachHang pn : listnv) {
//                    Object[] row = {
//                        pn.getMaKH(),pn.getHoTenKH(),pn.getSoDT(),pn.getDiaChi()
//                    };
//                    model.addRow(row);   
//                    
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//    }
//    public void showTablencatruc()
//    {
//        DefaultTableModel model = (DefaultTableModel) tblCaTruc.getModel();
//        model.setRowCount(0);
//        if(cboChoncot.getItemCount()<1 )
//        {
//            try {
//                List<CaTruc> list = CTDao.selectAll();
//                for (CaTruc pn : list) {
//                    Object[] row = {
//                        pn.getMacaTruc(),pn.getGiobatdau(),pn.getGioketca()
//                    };
//                    model.addRow(row);  
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//        else{
//            try {
//                String a;
//                if(cboSapxeptheo.getSelectedItem().equals("Tăng"))
//                {
//                    a = "ASC";
//                }
//                else{
//                    a= "DESC";
//                }
//
//                List<CaTruc> listnv = CTDao.selectAllbyentity(caTruc.getEntity().get(cboChoncot.getSelectedIndex()),a);
//                for (CaTruc pn : listnv) {
//                    Object[] row = {
//                        pn.getMacaTruc(),pn.getGiobatdau(),pn.getGioketca()
//                    };
//                    model.addRow(row);   
//                    
//                }
//            } 
//            catch (Exception e) {
//                JOptionPane.showMessageDialog(this, "Lỗi Truy Vấn Dữ Liệu 111!!");
//            }
//        }
//    }
//    public void fillChoncot(JTable a)
//    {
//        DefaultComboBoxModel model = (DefaultComboBoxModel) cboChoncot.getModel();
//        DefaultTableModel model1 = (DefaultTableModel) a.getModel();
//        model.removeAllElements();
//        int q = a.getColumnCount();
//        for(int i = 0 ;i<q;i++)
//        {
//            model.addElement(model1.getColumnName(i));
//        }
//    }
//    public void selectByid(JTable a)
//    {
//
//        nhanVien = NVdao.selectById(txtTimkiem.getText());
//        hoaDon = HDdao.selectById(txtTimkiem.getText());
//        if(pnlNhanvien.isShowing())
//        {
//            if(nhanVien!=null)
//            {
//                DefaultTableModel model = (DefaultTableModel) a.getModel();
//                model.setRowCount(0);
//                Object[] row = {
//                    nhanVien.getMaNV(),
//                    nhanVien.getHoTen(),
//                    nhanVien.getGioiTinh(),
//                    nhanVien.getsDt(),
//                    nhanVien.getDiaChi(),
//                    nhanVien.getMaCv(),
//                    nhanVien.getMaCatruc(),
//                    nhanVien.getLuong(),
//                    nhanVien.getMatKhau()};
//                model.addRow(row);
//            }
//            else
//            {
//                JOptionPane.showMessageDialog(this, "Không tìm thấy mã nhân viên!!");
//            }
//        }
//        else if(pnlHoadon.isShowing())
//        {
//            if(hoaDon!=null)
//            {
//                DefaultTableModel model = (DefaultTableModel) a.getModel();
//                model.setRowCount(0);
//                Object[] row = {
//                    hoaDon.getMaHoaDon(),hoaDon.getNgayLapHD(),hoaDon.getMaNV(),hoaDon.getHinhThucTT(),hoaDon.getMaKH()};
//                model.addRow(row);
//            }
//            else
//            {
//                JOptionPane.showMessageDialog(this, "Không tìm thấy Hóa Đơn!!");
//            }
//        }
//        
//            
//        
//        
//        
//        
//    }
//    public void getInfortable()
//    {
//        
//    }
//    void ketThuc(){
//        int a = JOptionPane.showConfirmDialog(this,"Bạn muốn kết thúc làm việc?","Hệ Thống",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
//        if(a==JOptionPane.YES_OPTION)
//        {
//            System.exit(0);
//        }
//    }
    private void init() {
        QLThongKe.setColsForNhanVien(tblNhanVien);
        QLNhanVien.fillTableNhanVien(tblNhanVien);
        QLThongKe.setColsForHoaDon(tblHoaDon);
        // Dung proceduce
        QLThongKe.setColsForPhieuNhap(tblPhieuNhap);
        QLThongKe.setColsForNguyenLieu(tblNguyenLieu);
        QLThongKe.setColsForCaTruc(tblCaTruc);
        QLThongKe.setColsForKhachHang(tblKhachHang);
        mnThongke.setEnabled(false);
        
        // Phan Quyen
        if (!Auth.isManager()) {
            tabs.remove(0);
            tabs.remove(0);
            tabs.remove(0);
            if (Auth.user.getMaCV().toString().equals("CV002")) {
                tabs.remove(1);
                tabs.remove(1);
                tabs.remove(1);
            } else if (Auth.user.getMaCV().toString().equals("CV003")) {
                tabs.remove(0);
            }
        }
    }
}
